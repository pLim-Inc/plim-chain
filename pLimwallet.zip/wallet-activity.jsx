// wallet-activity.jsx — Activity list + Tx detail + Pending + Connection
const { PLIM: _P, Logo: _Logo, Pill: _Pill, Btn: _Btn, Shell: _Shell, Mono: _Mono, FlowBadge: _FB, RailDot: _RD } = window;
const P = _P, Sh = _Shell, M = _Mono, FB = _FB, RD = _RD;

// ═══════════════ ACTIVITY LIST ═══════════════
function W_Activity() {
  const txs = [
    { dir:'in',  who:'Maria López',     amt:'+ €120,00',  tok:'EURC', rail:'SEPA',    transport:'HTTPS', flow:'P2AI', t:'há 12min', status:'ok',   agent:false },
    { dir:'out', who:'agent NovaShop',   amt:'- €34,80',   tok:'EURC', rail:'L99',     transport:'Mesh',  flow:'B2AI', t:'há 2h',    status:'pending', agent:true },
    { dir:'out', who:'plim:c8f…2a1e',    amt:'- 0,00018',  tok:'ePL',  rail:'P:L:I:M', transport:'WS',    flow:'AI2AI',t:'há 4h',    status:'ok',   agent:true },
    { dir:'in',  who:'João Pessoa Gov',  amt:'+ €580,00',  tok:'BRZ',  rail:'Stripe',  transport:'HTTPS', flow:'G2AI', t:'ontem 14:32', status:'ok', agent:false },
    { dir:'out', who:'Padaria Pão&Cia',  amt:'- €4,20',    tok:'EURC', rail:'SEPA',    transport:'HTTPS', flow:'P2AI', t:'ontem 09:18', status:'ok', agent:false },
    { dir:'out', who:'agent BookKeep',   amt:'- 0,012',    tok:'ePL',  rail:'P:L:I:M', transport:'MCP',   flow:'AI2AI',t:'qua 22:04', status:'ok',   agent:true },
    { dir:'in',  who:'Refund · iFood',   amt:'+ €18,90',   tok:'BRZ',  rail:'Stripe',  transport:'HTTPS', flow:'P2AI', t:'qua 12:11', status:'ok',   agent:false },
    { dir:'out', who:'Carlos Andrade',   amt:'- €5,00',    tok:'EURC', rail:'L99',     transport:'Mesh',  flow:'P2AI', t:'ter 18:40', status:'flag', agent:false },
  ];
  return (
    <Sh tab="activity" title="Atividade" sub="248 transações · últ. 30 dias" right={
      <div style={{display:'flex', gap:8}}>
        <div style={{
          width:36, height:36, borderRadius:18, background:'rgba(255,255,255,0.06)',
          display:'flex', alignItems:'center', justifyContent:'center',
        }}><window.Icon name="filter" size={18} color={P.ink}/></div>
        <div style={{
          width:36, height:36, borderRadius:18, background:'rgba(255,255,255,0.06)',
          display:'flex', alignItems:'center', justifyContent:'center',
        }}><window.Icon name="download" size={18} color={P.ink}/></div>
      </div>
    }>
      <div style={{padding:'0 16px 12px', overflow:'auto', height:'100%'}}>
        {/* search */}
        <div style={{
          padding:'12px 14px', borderRadius:12, background:'rgba(255,255,255,0.04)',
          border:`1px solid ${P.hairline}`,
          display:'flex', alignItems:'center', gap:10, marginBottom:12,
        }}>
          <window.Icon name="search" size={16} color={P.inkFaint}/>
          <span style={{fontSize:14, color:P.inkFaint}}>Buscar por nome, hash, memo…</span>
        </div>
        {/* filter chips */}
        <div style={{display:'flex', gap:6, marginBottom:14, overflow:'auto'}}>
          {[
            ['Tudo', true],
            ['Entradas', false],
            ['Saídas', false],
            ['Por agente', false],
            ['Pendente', false],
            ['Sinalizada', false],
          ].map(([t, on],i)=>(
            <div key={i} style={{
              padding:'7px 14px', borderRadius:999, whiteSpace:'nowrap',
              background: on ? P.ink : 'rgba(255,255,255,0.04)',
              color: on ? '#000' : P.inkDim,
              border:`1px solid ${on ? P.ink : P.hairline}`,
              fontSize:12, fontWeight:600, letterSpacing:-0.1,
            }}>{t}</div>
          ))}
        </div>

        {/* day header */}
        <div style={{padding:'4px 4px 10px', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div style={{fontSize:11, fontWeight:600, color:P.inkFaint, letterSpacing:0.5, textTransform:'uppercase'}}>Hoje · 14 mai</div>
          <span style={{fontSize:11, color:P.neon, fontFamily:P.mono, fontWeight:600}}>+ €120,00</span>
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:8}}>
          {txs.slice(0,3).map((r,i)=><Row key={i} r={r}/>)}
        </div>

        <div style={{padding:'18px 4px 10px', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div style={{fontSize:11, fontWeight:600, color:P.inkFaint, letterSpacing:0.5, textTransform:'uppercase'}}>Ontem · 13 mai</div>
          <span style={{fontSize:11, color:P.inkDim, fontFamily:P.mono, fontWeight:600}}>+ €575,80</span>
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:8}}>
          {txs.slice(3,5).map((r,i)=><Row key={i} r={r}/>)}
        </div>

        <div style={{padding:'18px 4px 10px', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div style={{fontSize:11, fontWeight:600, color:P.inkFaint, letterSpacing:0.5, textTransform:'uppercase'}}>Semana passada</div>
          <span style={{fontSize:11, color:P.inkDim, fontFamily:P.mono, fontWeight:600}}>+ €1 247,12</span>
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:8}}>
          {txs.slice(5).map((r,i)=><Row key={i} r={r}/>)}
        </div>
      </div>
    </Sh>
  );
}

const Row = ({ r }) => {
  const { Icon, T } = window;
  const statusColor = { ok:P.neon, pending:P.orange, flag:P.red }[r.status];
  return (
    <div style={{
      background:'rgba(255,255,255,0.03)', borderRadius:14,
      padding:'12px 14px', display:'flex', alignItems:'center', gap:12,
    }}>
      <div style={{
        width:38, height:38, borderRadius:'50%',
        background: r.dir==='in' ? `${P.neon}18` : 'rgba(255,255,255,0.05)',
        display:'flex', alignItems:'center', justifyContent:'center',
        flexShrink:0, position:'relative',
      }}>
        <Icon name={r.dir==='in' ? 'arrow-down' : 'arrow-up'} size={16}
              color={r.dir==='in' ? P.neon : P.ink} stroke={2}/>
        {r.agent && <div style={{
          position:'absolute', bottom:-2, right:-2, width:16, height:16, borderRadius:'50%',
          background:P.orange, border:`2px solid #06090A`,
          display:'flex', alignItems:'center', justifyContent:'center',
        }}>
          <Icon name="sparkle" size={9} color="#000" fill="#000" stroke={0}/>
        </div>}
      </div>
      <div style={{flex:1, minWidth:0}}>
        <div style={{fontSize:14, color:P.ink, fontWeight:600, letterSpacing:-0.1, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>{r.who}</div>
        <div style={{display:'flex', gap:8, alignItems:'center', marginTop:3}}>
          <FB_ flow={r.flow}/>
          <span style={{fontSize:11, color:P.inkDim}}>{r.t}</span>
          {r.status === 'pending' && (
            <span style={{fontSize:11, color:P.orange, display:'flex', alignItems:'center', gap:3}}>
              <span style={{width:5, height:5, borderRadius:'50%', background:P.orange}}/>
              pendente
            </span>
          )}
          {r.status === 'flag' && (
            <span style={{fontSize:11, color:P.red, display:'flex', alignItems:'center', gap:3}}>
              <Icon name="warning" size={11} color={P.red}/>
              sinalizada
            </span>
          )}
        </div>
      </div>
      <div style={{textAlign:'right', flexShrink:0}}>
        <div style={{fontSize:14, fontWeight:600, color: r.dir==='in' ? P.neon : P.ink, fontFamily:P.mono, letterSpacing:-0.3}}>{r.amt}</div>
        <div style={{fontSize:10, color:P.inkFaint, marginTop:1, fontFamily:P.mono, letterSpacing:0.3}}>{r.tok}</div>
      </div>
    </div>
  );
};

// ═══════════════ TX DETAIL — full OODA decision tree visible ═══════════════
function W_TxDetail() {
  const tabs = ['Geral','Recibo','Decisão','On-chain','Compliance'];
  const active = 2; // Decisão tab visible
  return (
    <Sh back title="Pagamento · INV-2026-0044" sub="TX 0x9f3a…c821 · €120,00 · settled">
      <div style={{padding:'0 0 12px', overflow:'auto', height:'100%'}}>
        {/* hero status */}
        <div style={{padding:'0 16px 12px'}}>
          <div style={{
            background:`linear-gradient(160deg, ${P.surface} 0%, #0a1014 100%)`,
            border:`1px solid ${P.neon}55`, borderRadius:18, padding:'16px 18px',
            boxShadow:`0 0 24px ${P.neon}11`,
          }}>
            <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
              <M size={10} color={P.neon}>● LIQUIDADO</M>
              <FB flow="B2AI"/>
            </div>
            <div style={{fontSize:30, fontWeight:700, fontFamily:P.mono, marginTop:6, letterSpacing:-0.5}}>
              €120,00 <span style={{fontSize:14, color:P.inkDim, fontWeight:500}}>EURC</span>
            </div>
            <div style={{fontSize:13, color:P.ink, marginTop:2}}>para <span style={{color:P.orange}}>Maria López</span></div>
            {/* timeline mini */}
            <div style={{
              marginTop:14, display:'flex', alignItems:'center', gap:6,
            }}>
              {['Assinada','Roteada','Aceita','Liquidada'].map((s, i) => (
                <div key={s} style={{flex:1, position:'relative'}}>
                  <div style={{
                    height:3, borderRadius:2,
                    background: i<=3 ? P.neon : 'rgba(255,255,255,0.1)',
                    boxShadow: i<=3 ? `0 0 6px ${P.neon}` : 'none',
                  }}/>
                  <div style={{fontSize:9, color:P.inkDim, marginTop:4, fontFamily:P.mono}}>{s}</div>
                </div>
              ))}
            </div>
            <M size={9} dim>completo em 8,2s · 14 mai 2026 · 09:32:18</M>
          </div>
        </div>

        {/* tabs */}
        <div style={{
          display:'flex', padding:'0 16px', gap:4, borderBottom:`1px solid ${P.hairline}`,
          position:'sticky', top:0, background:P.bg, zIndex:2,
        }}>
          {tabs.map((t, i) => (
            <div key={t} style={{
              padding:'10px 4px', position:'relative', flex:1, textAlign:'center',
              fontSize:11, fontWeight:600, color: i===active ? P.neon : P.inkDim,
            }}>
              {t}
              {i===active && <div style={{
                position:'absolute', bottom:-1, left:8, right:8, height:2,
                background:P.neon, borderRadius:2, boxShadow:`0 0 8px ${P.neon}`,
              }}/>}
            </div>
          ))}
        </div>

        {/* Decision tab content */}
        <div style={{padding:'16px'}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10}}>
            <M size={10} dim>OODA · DECISION RECORD</M>
            <M size={10} color={P.neon}>policy v0.4.1</M>
          </div>

          {/* observation snapshot collapsed */}
          <div style={{
            background:P.surface, border:`1px solid ${P.hairline}`, borderRadius:12,
            padding:'10px 12px', marginBottom:8,
          }}>
            <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
              <div style={{display:'flex', alignItems:'center', gap:8}}>
                <span style={{color:P.cyan, fontSize:12}}>◉</span>
                <span style={{fontSize:12, fontWeight:600, color:P.ink}}>Observação</span>
              </div>
              <span style={{color:P.inkFaint, fontSize:11}}>⌄</span>
            </div>
            <M size={10} dim>snapshot 09:32:09 · 4 rails healthy · 3 transports up · counterparty resolved · cap usage 26%</M>
          </div>

          {/* orient — chosen path */}
          <div style={{
            background:`${P.neonSoft}`, border:`1px solid ${P.neon}55`, borderRadius:12,
            padding:'12px', marginBottom:8,
          }}>
            <div style={{display:'flex', alignItems:'center', gap:8, marginBottom:8}}>
              <span style={{color:P.neon, fontSize:12}}>◈</span>
              <span style={{fontSize:12, fontWeight:600, color:P.ink}}>Decisão · SEPA Instant</span>
              <M size={9} color={P.neon}>score 94</M>
            </div>
            <div style={{display:'flex', flexDirection:'column', gap:5}}>
              {[
                'Menor custo · €0,02 vs €0,01–€0,00 das alternativas',
                'Contraparte em jurisdição MiCA (ES) · sem Travel Rule',
                'Sem quórum exigido · abaixo de €1.000',
                'Latência aceitável · 8s p95',
              ].map((b,i)=>(
                <div key={i} style={{display:'flex', gap:8, alignItems:'flex-start'}}>
                  <span style={{color:P.neon, fontSize:10, marginTop:2}}>✓</span>
                  <div style={{fontSize:11, color:P.ink, lineHeight:1.4}}>{b}</div>
                </div>
              ))}
            </div>
          </div>

          {/* alternatives not chosen */}
          <M size={10} dim>ALTERNATIVAS NÃO ESCOLHIDAS · 3</M>
          <div style={{display:'flex', flexDirection:'column', gap:6, marginTop:6}}>
            {[
              ['P:L:I:M nativo', 'recipiente não opta por receber em ePL'],
              ['USDC Solana',    'requer swap intermediário · custo total maior'],
              ['L99 mesh',       'rails internet saudáveis · mesh seria sub-ótimo'],
            ].map(([n, why], i) => (
              <div key={i} style={{
                background:P.surface, border:`1px solid ${P.hairline}`, borderRadius:10,
                padding:'8px 10px', display:'flex', alignItems:'center', gap:10,
              }}>
                <div style={{width:10, height:10, borderRadius:'50%', border:`1.5px solid ${P.inkFaint}`}}/>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{fontSize:11, fontWeight:600, color:P.ink}}>{n}</div>
                  <M size={9} dim>{why}</M>
                </div>
              </div>
            ))}
          </div>

          {/* user override (none) */}
          <div style={{
            marginTop:10, padding:'10px 12px', borderRadius:10,
            background:'transparent', border:`1px dashed ${P.hairline}`,
          }}>
            <M size={10} dim>USER OVERRIDE</M>
            <div style={{fontSize:11, color:P.ink, marginTop:2}}>nenhum · usuário aceitou a rota recomendada</div>
          </div>

          {/* replay link */}
          <div style={{marginTop:14, textAlign:'center'}}>
            <M size={11} color={P.neon}>↻ replay esta decisão com a política atual (shadow mode)</M>
          </div>
        </div>
      </div>
    </Sh>
  );
}

// ═══════════════ PENDING / L99 RECONCILIATION ═══════════════
function W_Pending() {
  return (
    <Sh back title="Pendentes" sub="3 EM RECONCILIAÇÃO · L99 ATIVO">
      <div style={{padding:'0 16px 12px', overflow:'auto', height:'100%'}}>
        {/* alert banner */}
        <div style={{
          padding:'12px 14px', borderRadius:14,
          background:`linear-gradient(135deg, ${P.orangeSoft} 0%, transparent 100%)`,
          border:`1px solid ${P.orange}55`,
          marginBottom:14,
        }}>
          <div style={{display:'flex', alignItems:'center', gap:10}}>
            <div style={{
              width:36, height:36, borderRadius:10,
              background:`${P.orange}22`, color:P.orange,
              display:'flex', alignItems:'center', justifyContent:'center',
              fontSize:18, fontFamily:P.mono,
            }}>≋</div>
            <div style={{flex:1}}>
              <div style={{fontSize:13, fontWeight:600, color:P.ink}}>Internet intermitente</div>
              <M size={11}>3 pagamentos via mesh · reconcilia ao reconectar</M>
            </div>
          </div>
          <div style={{display:'flex', gap:8, marginTop:10}}>
            <M size={10} color={P.cyan}>● mesh 4 peers</M>
            <M size={10} dim>· último relay há 18s</M>
            <M size={10} dim>· bateria nó 78%</M>
          </div>
        </div>

        {/* pending txs */}
        <div style={{display:'flex', flexDirection:'column', gap:10}}>
          {[
            { who:'Carlos Andrade',  amt:'€5,00',  tok:'EURC', state:2, eta:'~30s', age:'há 14min' },
            { who:'plim:8a1f…7c2d',  amt:'€0,12',  tok:'ePL',  state:1, eta:'~2min',  age:'há 38min' },
            { who:'Padaria Pão&Cia', amt:'€4,20',  tok:'EURC', state:3, eta:'~5min',  age:'há 4h' },
          ].map((p,i)=>{
            const steps = ['Assinada','Enfileirada','Relayed (mesh)','Aguarda reconciliação','Liquidada'];
            return (
              <div key={i} style={{
                background:P.surface, border:`1px solid ${P.hairline}`, borderRadius:14,
                padding:'12px 14px',
              }}>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
                  <div style={{fontSize:14, fontWeight:600, color:P.ink}}>{p.who}</div>
                  <div style={{fontSize:14, fontWeight:600, color:P.ink, fontFamily:P.mono}}>{p.amt}</div>
                </div>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginTop:2}}>
                  <M size={10}>{p.tok} · {p.age}</M>
                  <M size={10} color={P.orange}>ETA {p.eta}</M>
                </div>
                {/* state timeline */}
                <div style={{
                  marginTop:12, display:'flex', alignItems:'center', gap:4,
                }}>
                  {steps.map((s, idx) => (
                    <div key={s} style={{flex:1}}>
                      <div style={{
                        height:3, borderRadius:2,
                        background: idx <= p.state ? (idx === p.state ? P.orange : P.neon) : 'rgba(255,255,255,0.1)',
                        boxShadow: idx === p.state ? `0 0 8px ${P.orange}` : 'none',
                      }}/>
                      <div style={{
                        fontSize:8, color: idx === p.state ? P.orange : P.inkFaint,
                        marginTop:4, fontFamily:P.mono, letterSpacing:0.3,
                      }}>{s.toUpperCase()}</div>
                    </div>
                  ))}
                </div>
                {/* actions */}
                <div style={{display:'flex', gap:8, marginTop:12}}>
                  <div style={{
                    flex:1, height:30, borderRadius:8,
                    background:'rgba(255,255,255,0.04)', border:`1px solid ${P.hairline}`,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:11, color: p.state >= 2 ? P.inkFaint : P.ink, fontWeight:600,
                    opacity: p.state >= 2 ? 0.5 : 1,
                  }}>Cancelar</div>
                  <div style={{
                    flex:1, height:30, borderRadius:8,
                    background:`${P.neon}22`, border:`1px solid ${P.neon}55`,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:11, color:P.neon, fontWeight:600,
                  }}>↻ Reconciliar</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Sh>
  );
}

// ═══════════════ CONNECTION / L99 status ═══════════════
function W_Connection() {
  const transports = [
    ['Internet (HTTPS)', 'on',   'p95 142ms'],
    ['Real-time (WS)',   'on',   '7 conn'],
    ['Agent (MCP)',      'on',   '3 sessions'],
    ['Relay (Nostr)',    'warn', '2/4 relays'],
    ['Mesh (L99)',       'on',   '4 peers · 240m'],
  ];
  return (
    <Sh back title="Conexão" sub="L99 MESH · 4 PEERS · 1 NÓ ATIVO">
      <div style={{padding:'0 16px 12px', overflow:'auto', height:'100%'}}>
        {/* transports */}
        <M size={10} dim>TRANSPORTES</M>
        <div style={{
          marginTop:6, background:P.surface, border:`1px solid ${P.hairline}`, borderRadius:14,
          overflow:'hidden',
        }}>
          {transports.map(([name, st, detail], i) => {
            const c = st === 'on' ? P.neon : st === 'warn' ? P.orange : P.red;
            return (
              <div key={name} style={{
                padding:'12px 14px', display:'flex', alignItems:'center', gap:12,
                borderTop: i ? `1px solid ${P.hairline}` : 'none',
              }}>
                <div style={{
                  width:10, height:10, borderRadius:'50%', background:c,
                  boxShadow:`0 0 8px ${c}`, flexShrink:0,
                }}/>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{fontSize:13, fontWeight:600, color:P.ink}}>{name}</div>
                  <M size={10}>{detail}</M>
                </div>
                {/* mini uptime sparkline */}
                <svg width="60" height="20" viewBox="0 0 60 20">
                  {Array.from({length:24}).map((_,j)=>{
                    const h = st === 'warn' && j > 16 ? 4 : 14 - (j%3);
                    return <rect key={j} x={j*2.5} y={20-h} width="1.5" height={h} fill={c} opacity={0.7}/>;
                  })}
                </svg>
              </div>
            );
          })}
        </div>

        {/* mesh map */}
        <M size={10} dim>PARES PRÓXIMOS</M>
        <div style={{
          marginTop:6, position:'relative', height:200,
          borderRadius:18, background:P.surface, border:`1px solid ${P.hairline}`, overflow:'hidden',
        }}>
          {/* grid bg */}
          <div style={{
            position:'absolute', inset:0,
            backgroundImage:`linear-gradient(${P.neon}10 1px, transparent 1px), linear-gradient(90deg, ${P.neon}10 1px, transparent 1px)`,
            backgroundSize:'20px 20px',
          }}/>
          {/* rings */}
          {[50, 80, 120].map((r,i)=>(
            <div key={i} style={{
              position:'absolute', top:'50%', left:'50%',
              width:r*2, height:r*2, marginLeft:-r, marginTop:-r,
              border:`1px solid ${P.neon}${['44','22','11'][i]}`, borderRadius:'50%',
            }}/>
          ))}
          {/* center self */}
          <div style={{
            position:'absolute', top:'50%', left:'50%', marginLeft:-14, marginTop:-14,
            width:28, height:28, borderRadius:10,
            background:P.neon, color:'#001a08',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:10, fontWeight:700, fontFamily:P.mono,
            boxShadow:`0 0 20px ${P.neonGlow}`,
          }}>YOU</div>
          {/* peers */}
          {[
            [70,40,P.neon,'A8F3','BLE'],
            [280,60,P.orange,'C12E','LoRa'],
            [80,150,P.cyan,'7D9A','WiFi'],
            [260,140,P.neon,'B441','LoRa'],
          ].map(([x,y,c,id,kind],i)=>(
            <div key={i} style={{
              position:'absolute', left:x-12, top:y-12,
            }}>
              <div style={{
                width:24, height:24, borderRadius:'50%',
                background:'#06090A', border:`1.5px solid ${c}`,
                display:'flex', alignItems:'center', justifyContent:'center',
                fontSize:8, fontWeight:700, color:c, fontFamily:P.mono,
                boxShadow:`0 0 12px ${c}66`,
              }}>{kind}</div>
              <div style={{
                position:'absolute', top:26, left:'50%', transform:'translateX(-50%)',
                whiteSpace:'nowrap', fontFamily:P.mono, fontSize:8, color:P.inkDim,
              }}>{id}</div>
            </div>
          ))}
          <div style={{position:'absolute', top:10, left:12}}>
            <M size={9} color={P.neon}>● MESH ATIVO · 4 PEERS</M>
          </div>
        </div>

        {/* hardware */}
        <M size={10} dim>SEU HARDWARE</M>
        <div style={{
          marginTop:6, background:P.surface, border:`1px solid ${P.hairline}`, borderRadius:14,
          padding:'14px', display:'flex', flexDirection:'column', gap:10,
        }}>
          <div style={{display:'flex', alignItems:'center', gap:12}}>
            <div style={{
              width:42, height:42, borderRadius:10,
              background:`${P.cyan}18`, border:`1px solid ${P.cyan}44`,
              color:P.cyan, display:'flex', alignItems:'center', justifyContent:'center',
              fontSize:18, fontFamily:P.mono,
            }}>◫</div>
            <div style={{flex:1, minWidth:0}}>
              <div style={{fontSize:13, fontWeight:600, color:P.ink, fontFamily:P.mono}}>plim-node-a8f3</div>
              <M size={10}>Blackbox · solar externa · firmware 0.4.1</M>
            </div>
            <M size={10} color={P.neon}>● online</M>
          </div>
          {/* battery */}
          <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
            <M size={10} dim>BATERIA · 7d</M>
            <M size={10} color={P.neon}>78% · ↑ carregando</M>
          </div>
          <svg width="100%" height="40" viewBox="0 0 280 40" preserveAspectRatio="none">
            <defs>
              <linearGradient id="batGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={P.neon} stopOpacity="0.6"/>
                <stop offset="100%" stopColor={P.neon} stopOpacity="0"/>
              </linearGradient>
            </defs>
            <path d="M0,30 L20,28 L40,18 L60,22 L80,10 L100,14 L120,8 L140,16 L160,12 L180,6 L200,18 L220,12 L240,8 L260,4 L280,8 L280,40 L0,40 Z"
                  fill="url(#batGrad)"/>
            <path d="M0,30 L20,28 L40,18 L60,22 L80,10 L100,14 L120,8 L140,16 L160,12 L180,6 L200,18 L220,12 L240,8 L260,4 L280,8"
                  stroke={P.neon} strokeWidth="1.5" fill="none"/>
          </svg>
          <div style={{
            padding:'8px 10px', borderRadius:8,
            background:'rgba(255,255,255,0.03)', border:`1px solid ${P.hairline}`,
            fontSize:11, color:P.ink, display:'flex', alignItems:'center', justifyContent:'space-between',
          }}>
            <span>+ Registrar novo dispositivo</span>
            <span style={{color:P.neon}}>→</span>
          </div>
        </div>
      </div>
    </Sh>
  );
}

Object.assign(window, { W_Activity, W_TxDetail, W_Pending, W_Connection });
