// wallet-agents.jsx — Agents list + Agent detail
const { PLIM: AP, Pill: AP_Pill, Btn: AP_Btn, Shell: AP_Sh, Mono: AP_M, FlowBadge: AP_FB } = window;
const P_ = AP, Sh_ = AP_Sh, M_ = AP_M, FB_ = AP_FB, Pill_ = AP_Pill;

// ═══════════════ AGENTS LIST ═══════════════
function W_Agents() {
  const agents = [
    {
      name:'NovaShop',     desc:'Pagamentos de fornecedores B2AI',
      flow:'B2AI', status:'active',
      model:'llama-3.3-70b · LoRA pLim-merchant-v2',
      mandate:{ daily:500, used:155.20, period:'hoje' },
      pending:2, last:'há 8min',
      accent: P_.orange,
    },
    {
      name:'BookKeep',     desc:'Reconcilia recibos & fatura clientes',
      flow:'AI2AI', status:'active',
      model:'qwen-2.5-32b · LoRA pLim-acct-v1',
      mandate:{ daily:50, used:12.40, period:'hoje' },
      pending:0, last:'há 2h',
      accent: '#C792FF',
    },
    {
      name:'CityPay',      desc:'Pagamentos delegados pelo município',
      flow:'G2AI', status:'mandate_expiring',
      model:'gpt-oss-20b · LoRA pLim-gov-v0',
      mandate:{ daily:2000, used:0, period:'hoje' },
      pending:0, last:'ontem',
      accent: P_.cyan,
    },
    {
      name:'RefundBot',    desc:'Processa reembolsos automatizados',
      flow:'P2AI', status:'paused',
      model:'mistral-7b · LoRA pLim-cs-v3',
      mandate:{ daily:100, used:0, period:'hoje' },
      pending:0, last:'há 3d',
      accent: P_.inkFaint,
    },
  ];
  return (
    <Sh_ tab="agents" title="Agentes" sub="4 REGISTRADOS · 3 ATIVOS" right={
      <div style={{
        padding:'4px 10px', borderRadius:999, background:P_.neon, color:'#001a08',
        fontSize:10, fontWeight:700, fontFamily:P_.mono, letterSpacing:0.5,
        boxShadow:`0 0 12px ${P_.neonGlow}`,
      }}>+ NOVO</div>
    }>
      <div style={{padding:'0 16px 12px', overflow:'auto', height:'100%'}}>
        {/* attention banner */}
        <div style={{
          padding:'10px 12px', borderRadius:12,
          background:`${P_.cyan}10`, border:`1px solid ${P_.cyan}44`,
          display:'flex', alignItems:'center', gap:10, marginBottom:12,
        }}>
          <span style={{color:P_.cyan, fontSize:14}}>ⓘ</span>
          <div style={{fontSize:11, color:P_.ink, lineHeight:1.4}}>
            <span style={{color:P_.cyan, fontWeight:600}}>CityPay</span> · mandato expira em 6 dias. Renovar agora.
          </div>
        </div>

        <div style={{display:'flex', flexDirection:'column', gap:10}}>
          {agents.map(a => {
            const pct = (a.mandate.used / a.mandate.daily) * 100;
            return (
              <div key={a.name} style={{
                background:P_.surface, border:`1px solid ${a.status==='active' ? a.accent+'44' : P_.hairline}`,
                borderRadius:16, padding:'14px 14px',
                opacity: a.status === 'paused' ? 0.6 : 1,
                boxShadow: a.status === 'mandate_expiring' ? `0 0 0 1px ${P_.cyan}33` : 'none',
              }}>
                <div style={{display:'flex', alignItems:'center', gap:12}}>
                  <div style={{
                    width:44, height:44, borderRadius:12,
                    background:`linear-gradient(135deg, ${a.accent}33 0%, ${a.accent}11 100%)`,
                    border:`1px solid ${a.accent}66`,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    color:a.accent, fontSize:20, fontFamily:P_.mono, fontWeight:700,
                    flexShrink:0, position:'relative',
                  }}>
                    ◇
                    {a.pending > 0 && <div style={{
                      position:'absolute', top:-4, right:-4, width:18, height:18, borderRadius:'50%',
                      background:P_.orange, color:'#000', fontSize:10, fontWeight:700,
                      display:'flex', alignItems:'center', justifyContent:'center',
                      border:`2px solid ${P_.surface}`,
                    }}>{a.pending}</div>}
                  </div>
                  <div style={{flex:1, minWidth:0}}>
                    <div style={{display:'flex', alignItems:'center', gap:6}}>
                      <div style={{fontSize:14, fontWeight:600, color:P_.ink}}>{a.name}</div>
                      <FB_ flow={a.flow}/>
                    </div>
                    <div style={{fontSize:11, color:P_.inkDim, marginTop:2}}>{a.desc}</div>
                  </div>
                  <div style={{color:P_.inkFaint, fontSize:16}}>›</div>
                </div>
                {/* mandate gauge */}
                <div style={{marginTop:12}}>
                  <div style={{display:'flex', justifyContent:'space-between', marginBottom:4}}>
                    <M_ size={9} dim>MANDATO · {a.mandate.period.toUpperCase()}</M_>
                    <M_ size={9} color={a.status==='paused' ? P_.inkFaint : a.accent}>
                      €{a.mandate.used.toFixed(2)} / €{a.mandate.daily}
                    </M_>
                  </div>
                  <div style={{height:3, borderRadius:2, background:'rgba(255,255,255,0.08)', overflow:'hidden'}}>
                    <div style={{
                      width:`${pct}%`, height:'100%',
                      background:a.accent, boxShadow:`0 0 6px ${a.accent}`,
                    }}/>
                  </div>
                </div>
                {/* meta row */}
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginTop:8}}>
                  <M_ size={9} dim>{a.model.split(' · ')[0]}</M_>
                  <div style={{display:'flex', gap:8}}>
                    <M_ size={9} dim>última ação {a.last}</M_>
                    {a.status==='active' && <M_ size={9} color={P_.neon}>● ativo</M_>}
                    {a.status==='paused' && <M_ size={9} dim>⏸ pausado</M_>}
                    {a.status==='mandate_expiring' && <M_ size={9} color={P_.cyan}>△ expirando</M_>}
                  </div>
                </div>
              </div>
            );
          })}

          {/* new agent CTA */}
          <div style={{
            marginTop:6, padding:'18px 14px', borderRadius:16,
            border:`1px dashed ${P_.neon}55`, background:'transparent',
            display:'flex', alignItems:'center', gap:12,
          }}>
            <div style={{
              width:44, height:44, borderRadius:12, background:`${P_.neon}18`,
              border:`1px solid ${P_.neon}55`,
              display:'flex', alignItems:'center', justifyContent:'center',
              color:P_.neon, fontSize:22, fontWeight:300,
            }}>+</div>
            <div style={{flex:1}}>
              <div style={{fontSize:13, fontWeight:600, color:P_.ink}}>Registrar novo agente</div>
              <M_ size={10}>HuggingFace model URL · mandato · quórum</M_>
            </div>
          </div>
        </div>
      </div>
    </Sh_>
  );
}

// ═══════════════ AGENT DETAIL ═══════════════
function W_AgentDetail() {
  const tabs = ['Geral','Mandato','Performance','Atividade','Compliance'];
  const active = 1; // Mandate visible
  return (
    <Sh_ back title="NovaShop" sub="AGENTE B2AI · ATIVO · €155,20 HOJE">
      <div style={{padding:'0', overflow:'auto', height:'100%'}}>
        {/* hero */}
        <div style={{padding:'0 16px 12px'}}>
          <div style={{
            padding:'16px 16px', borderRadius:18,
            background:`linear-gradient(135deg, ${P_.orangeSoft} 0%, ${P_.surface} 100%)`,
            border:`1px solid ${P_.orange}55`,
            display:'flex', alignItems:'center', gap:14,
          }}>
            <div style={{
              width:54, height:54, borderRadius:14,
              background:`linear-gradient(135deg, ${P_.orange} 0%, #FFB870 100%)`,
              color:'#1a0a00', display:'flex', alignItems:'center', justifyContent:'center',
              fontSize:24, fontFamily:P_.mono, fontWeight:700,
              boxShadow:`0 0 24px ${P_.orange}66`,
            }}>◇</div>
            <div style={{flex:1, minWidth:0}}>
              <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:2}}>
                <div style={{fontSize:18, fontWeight:700, color:P_.ink, letterSpacing:-0.3}}>NovaShop</div>
                <FB_ flow="B2AI"/>
              </div>
              <M_ size={10}>Pagamentos de fornecedores · operador @pedro</M_>
              <div style={{display:'flex', gap:8, marginTop:6}}>
                <M_ size={9} color={P_.neon}>● ativo</M_>
                <M_ size={9} dim>· registrado 03 mai 2026</M_>
                <M_ size={9} dim>· 47 decisões</M_>
              </div>
            </div>
          </div>
        </div>

        {/* tabs */}
        <div style={{
          display:'flex', padding:'0 16px', gap:4, borderBottom:`1px solid ${P_.hairline}`,
          position:'sticky', top:0, background:P_.bg, zIndex:2,
        }}>
          {tabs.map((t, i) => (
            <div key={t} style={{
              padding:'10px 4px', position:'relative', flex:1, textAlign:'center',
              fontSize:11, fontWeight:600, color: i===active ? P_.neon : P_.inkDim,
            }}>
              {t}
              {i===active && <div style={{
                position:'absolute', bottom:-1, left:8, right:8, height:2,
                background:P_.neon, borderRadius:2, boxShadow:`0 0 8px ${P_.neon}`,
              }}/>}
            </div>
          ))}
        </div>

        {/* Mandate tab */}
        <div style={{padding:'16px'}}>
          {/* model attestation */}
          <M_ size={10} dim>MODELO ATTESTED</M_>
          <div style={{
            marginTop:6, padding:'12px 14px', borderRadius:12,
            background:P_.surface, border:`1px solid ${P_.neon}44`,
          }}>
            <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
              <div style={{fontSize:13, fontWeight:600, color:P_.ink}}>llama-3.3-70b</div>
              <M_ size={9} color={P_.neon}>✓ allowlist</M_>
            </div>
            <M_ size={10}>LoRA: pLim-merchant-v2.1 · 240MB</M_>
            <div style={{marginTop:6, padding:'6px 8px', borderRadius:6, background:'rgba(0,0,0,0.3)'}}>
              <M_ size={10}>sha256:a8f3c2e9b441d97f3a02e8c12d56e9a4f3c2…b441</M_>
            </div>
          </div>

          {/* limits */}
          <M_ size={10} dim>LIMITES</M_>
          <div style={{
            marginTop:6, background:P_.surface, border:`1px solid ${P_.hairline}`, borderRadius:12,
            overflow:'hidden',
          }}>
            {[
              ['Limite diário',    '€500,00',  '€155,20 usado', 0.31],
              ['Limite mensal',    '€8.000,00','€2.140,40 usado', 0.27],
              ['Por transação',    '€250,00',  '—', null],
            ].map(([k, v, sub, pct], i) => (
              <div key={k} style={{
                padding:'12px 14px', borderTop: i ? `1px solid ${P_.hairline}` : 'none',
              }}>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline'}}>
                  <M_ size={11} color={P_.ink}>{k}</M_>
                  <div style={{fontSize:13, fontWeight:600, color:P_.ink, fontFamily:P_.mono}}>{v}</div>
                </div>
                {pct !== null && (
                  <>
                    <div style={{marginTop:4, height:3, borderRadius:2, background:'rgba(255,255,255,0.08)', overflow:'hidden'}}>
                      <div style={{width:`${pct*100}%`, height:'100%', background:P_.orange, boxShadow:`0 0 6px ${P_.orange}`}}/>
                    </div>
                    <M_ size={9} dim>{sub}</M_>
                  </>
                )}
              </div>
            ))}
          </div>

          {/* allowed scope */}
          <M_ size={10} dim>ESCOPO PERMITIDO</M_>
          <div style={{
            marginTop:6, background:P_.surface, border:`1px solid ${P_.hairline}`, borderRadius:12,
            padding:'12px 14px',
          }}>
            <div style={{display:'flex', flexDirection:'column', gap:10}}>
              {[
                ['Tokens',         ['EURC','USDC','ePL'],         P_.neon],
                ['Rails',          ['SEPA','P:L:I:M','Stripe'],   P_.cyan],
                ['Transportes',    ['HTTPS','WS'],                P_.ink],
                ['Contrapartes',   ['lista 12 fornecedores ↗'],   P_.orange],
              ].map(([k, vals, c], i) => (
                <div key={k} style={{display:'flex', alignItems:'center', gap:10}}>
                  <M_ size={10} dim>{String(k).toUpperCase()}</M_>
                  <div style={{flex:1, display:'flex', gap:4, flexWrap:'wrap'}}>
                    {vals.map((v,j)=>(
                      <div key={j} style={{
                        padding:'3px 8px', borderRadius:6,
                        background:`${c}14`, border:`1px solid ${c}33`,
                        fontFamily:P_.mono, fontSize:10, fontWeight:600, color:c,
                      }}>{v}</div>
                    ))}
                  </div>
                </div>
              ))}
              <div style={{display:'flex', alignItems:'center', gap:10, paddingTop:8, borderTop:`1px solid ${P_.hairline}`}}>
                <M_ size={10} dim>MESH (L99)</M_>
                <div style={{flex:1}}>
                  <M_ size={11} color={P_.orange}>permitido · até €100 offline</M_>
                </div>
              </div>
            </div>
          </div>

          {/* quorum */}
          <div style={{
            marginTop:12, padding:'12px 14px', borderRadius:12,
            background:`${P_.cyan}10`, border:`1px solid ${P_.cyan}44`,
            display:'flex', alignItems:'center', gap:10,
          }}>
            <span style={{color:P_.cyan, fontSize:18, fontFamily:P_.mono}}>⟁</span>
            <div style={{flex:1}}>
              <div style={{fontSize:12, fontWeight:600, color:P_.ink}}>Quórum 2-de-3 acima de €250</div>
              <M_ size={10}>co-signers: você · @CFO · @Treasurer</M_>
            </div>
          </div>

          {/* expiry */}
          <div style={{
            marginTop:8, padding:'12px 14px', borderRadius:12,
            background:P_.surface, border:`1px solid ${P_.hairline}`,
            display:'flex', alignItems:'center', justifyContent:'space-between',
          }}>
            <div>
              <M_ size={10} dim>EXPIRA</M_>
              <div style={{fontSize:13, color:P_.ink, fontFamily:P_.mono, marginTop:2}}>10 jun 2026 · em 27 dias</div>
            </div>
            <M_ size={11} color={P_.neon}>renovar →</M_>
          </div>

          {/* actions */}
          <div style={{display:'flex', gap:8, marginTop:14}}>
            <div style={{flex:1}}><AP_Btn variant="ghost">⏸ Pausar agente</AP_Btn></div>
            <div style={{flex:1}}><AP_Btn variant="primary">Editar mandato</AP_Btn></div>
          </div>
        </div>
      </div>
    </Sh_>
  );
}

Object.assign(window, { W_Agents, W_AgentDetail });
