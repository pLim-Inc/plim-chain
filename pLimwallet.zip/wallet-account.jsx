// wallet-account.jsx — Security + Settings + Analytics
const { PLIM: AcP, Pill: AcPill, Btn: AcBtn, Shell: AcSh, Mono: AcM, FlowBadge: AcFB } = window;
const X = AcP, ShX = AcSh, MX = AcM;

// ═══════════════ SECURITY ═══════════════
function W_Security() {
  const Card = ({ icon, title, sub, status, statusColor, children }) => (
    <div style={{
      background:X.surface, border:`1px solid ${X.hairline}`, borderRadius:14,
      padding:'14px 14px',
    }}>
      <div style={{display:'flex', alignItems:'center', gap:12}}>
        <div style={{
          width:36, height:36, borderRadius:10,
          background:`${statusColor || X.neon}14`,
          border:`1px solid ${statusColor || X.neon}44`,
          color:statusColor || X.neon,
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:16, fontFamily:X.mono,
        }}>{icon}</div>
        <div style={{flex:1, minWidth:0}}>
          <div style={{fontSize:13, fontWeight:600, color:X.ink}}>{title}</div>
          <MX size={10}>{sub}</MX>
        </div>
        {status && <MX size={10} color={statusColor}>{status}</MX>}
      </div>
      {children && <div style={{marginTop:12, paddingTop:12, borderTop:`1px solid ${X.hairline}`}}>{children}</div>}
    </div>
  );

  return (
    <ShX tab="settings" back title="Segurança" sub="CHAVES · MANDATOS · SESSÕES">
      <div style={{padding:'0 16px 16px', overflow:'auto', height:'100%'}}>
        {/* score */}
        <div style={{
          padding:'14px 16px', borderRadius:18, marginBottom:14,
          background:`linear-gradient(135deg, ${X.neonSoft} 0%, ${X.surface} 100%)`,
          border:`1px solid ${X.neon}55`,
          boxShadow:`0 0 24px ${X.neon}11`,
          display:'flex', alignItems:'center', gap:14,
        }}>
          {/* radial score */}
          <div style={{position:'relative', width:64, height:64, flexShrink:0}}>
            <svg width="64" height="64" viewBox="0 0 64 64" style={{transform:'rotate(-90deg)'}}>
              <circle cx="32" cy="32" r="26" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="5"/>
              <circle cx="32" cy="32" r="26" fill="none" stroke={X.neon} strokeWidth="5"
                      strokeDasharray={`${2*Math.PI*26*0.84} ${2*Math.PI*26}`} strokeLinecap="round"
                      style={{filter:`drop-shadow(0 0 6px ${X.neonGlow})`}}/>
            </svg>
            <div style={{
              position:'absolute', inset:0, display:'flex', flexDirection:'column',
              alignItems:'center', justifyContent:'center',
            }}>
              <div style={{fontSize:18, fontWeight:700, color:X.ink, fontFamily:X.mono}}>84</div>
              <div style={{fontSize:7, color:X.inkDim, fontFamily:X.mono, letterSpacing:1}}>/100</div>
            </div>
          </div>
          <div style={{flex:1}}>
            <div style={{fontSize:14, fontWeight:600, color:X.ink}}>Saúde da conta</div>
            <MX size={11}>3 melhorias sugeridas · 1 ação crítica pendente</MX>
            <MX size={10} color={X.orange}>↑ adicionar guardião MPC</MX>
          </div>
        </div>

        {/* sign-in methods */}
        <MX size={10} dim>MÉTODOS DE LOGIN</MX>
        <div style={{marginTop:6, display:'flex', flexDirection:'column', gap:8}}>
          <Card icon="⌖" title="Face ID · iPhone 15" sub="usado há 8min · iCloud Keychain"
                status="● ativo" statusColor={X.neon}/>
          <Card icon="⌨" title="Seed 24 palavras" sub="confirmada · não armazenada"
                status="✓ verificada" statusColor={X.neon}/>
          <Card icon="⟁" title="MPC guardiões"
                sub="0 de 2 · adicione contatos de confiança"
                status="△ ação" statusColor={X.orange}/>
        </div>

        {/* limits */}
        <MX size={10} dim>LIMITES PESSOAIS</MX>
        <div style={{marginTop:6, background:X.surface, border:`1px solid ${X.hairline}`, borderRadius:14, overflow:'hidden'}}>
          {[
            ['Limite diário', '€1.000', 'KYC básico'],
            ['Por transação', '€500', 'autoimposto'],
            ['Offline (mesh)', '€100', 'sem internet'],
          ].map(([k,v,sub],i)=>(
            <div key={k} style={{
              padding:'12px 14px', display:'flex', alignItems:'center', justifyContent:'space-between',
              borderTop: i ? `1px solid ${X.hairline}` : 'none',
            }}>
              <div>
                <div style={{fontSize:12, color:X.ink, fontWeight:500}}>{k}</div>
                <MX size={9} dim>{sub}</MX>
              </div>
              <div style={{display:'flex', alignItems:'center', gap:8}}>
                <div style={{fontSize:13, color:X.ink, fontFamily:X.mono, fontWeight:600}}>{v}</div>
                <span style={{color:X.inkFaint, fontSize:14}}>›</span>
              </div>
            </div>
          ))}
        </div>

        {/* active sessions */}
        <MX size={10} dim>SESSÕES ATIVAS · 2</MX>
        <div style={{marginTop:6, background:X.surface, border:`1px solid ${X.hairline}`, borderRadius:14, overflow:'hidden'}}>
          {[
            ['📱', 'iPhone 15 · Lisbon, PT', 'agora · esta sessão', X.neon],
            ['💻', 'MacBook Pro · Lisbon, PT', 'há 2 dias · Safari', X.inkDim],
          ].map(([emoji, name, when, c], i) => (
            <div key={i} style={{
              padding:'12px 14px', display:'flex', alignItems:'center', gap:12,
              borderTop: i ? `1px solid ${X.hairline}` : 'none',
            }}>
              <div style={{
                width:32, height:32, borderRadius:8, background:'rgba(255,255,255,0.05)',
                display:'flex', alignItems:'center', justifyContent:'center', fontSize:14,
              }}>{emoji}</div>
              <div style={{flex:1, minWidth:0}}>
                <div style={{fontSize:12, color:X.ink, fontWeight:500}}>{name}</div>
                <MX size={9}>{when}</MX>
              </div>
              {i === 0 ? <MX size={10} color={c}>● atual</MX>
                       : <div style={{fontSize:10, color:X.red, fontWeight:600}}>Encerrar</div>}
            </div>
          ))}
        </div>

        {/* audit */}
        <div style={{
          marginTop:14, padding:'12px 14px', borderRadius:12,
          background:X.surface, border:`1px solid ${X.hairline}`,
          display:'flex', alignItems:'center', gap:10,
        }}>
          <div style={{
            width:32, height:32, borderRadius:8, background:`${X.cyan}14`,
            border:`1px solid ${X.cyan}44`, color:X.cyan,
            display:'flex', alignItems:'center', justifyContent:'center', fontSize:14,
          }}>≡</div>
          <div style={{flex:1}}>
            <div style={{fontSize:12, color:X.ink, fontWeight:600}}>Log de auditoria · 90 dias</div>
            <MX size={9}>74 eventos · exportar PDF assinado</MX>
          </div>
          <span style={{color:X.inkFaint, fontSize:14}}>›</span>
        </div>

        <div style={{
          marginTop:18, padding:'12px 14px', borderRadius:12,
          background:'transparent', border:`1px solid ${X.red}33`,
          display:'flex', alignItems:'center', gap:10,
        }}>
          <span style={{color:X.red, fontSize:14}}>⚠</span>
          <div style={{flex:1}}>
            <div style={{fontSize:12, color:X.red, fontWeight:600}}>Reportar comprometimento</div>
            <MX size={9}>revoga todos mandatos imediatamente</MX>
          </div>
        </div>
      </div>
    </ShX>
  );
}

// ═══════════════ SETTINGS ═══════════════
function W_Settings() {
  const Section = ({ title, children }) => (
    <>
      <MX size={10} dim>{title}</MX>
      <div style={{marginTop:6, marginBottom:14, background:X.surface, border:`1px solid ${X.hairline}`, borderRadius:14, overflow:'hidden'}}>
        {children}
      </div>
    </>
  );
  const Item2 = ({ icon, label, value, danger, last, toggle }) => (
    <div style={{
      padding:'12px 14px', display:'flex', alignItems:'center', gap:12,
      borderBottom: last ? 'none' : `1px solid ${X.hairline}`,
    }}>
      {icon && <div style={{
        width:28, height:28, borderRadius:8,
        background: danger ? `${X.red}14` : 'rgba(255,255,255,0.04)',
        color: danger ? X.red : X.inkDim,
        display:'flex', alignItems:'center', justifyContent:'center', fontSize:13,
      }}>{icon}</div>}
      <div style={{flex:1, minWidth:0}}>
        <div style={{fontSize:13, color: danger ? X.red : X.ink, fontWeight:500}}>{label}</div>
      </div>
      {value && <MX size={11} color={X.inkDim}>{value}</MX>}
      {toggle !== undefined ? (
        <div style={{
          width:36, height:22, borderRadius:11, padding:2,
          background: toggle ? X.neon : 'rgba(255,255,255,0.08)',
          boxShadow: toggle ? `0 0 10px ${X.neonGlow}` : 'none',
          display:'flex', justifyContent: toggle ? 'flex-end' : 'flex-start',
        }}>
          <div style={{width:18, height:18, borderRadius:'50%', background:'#000'}}/>
        </div>
      ) : (
        <span style={{color:X.inkFaint, fontSize:14}}>›</span>
      )}
    </div>
  );

  return (
    <ShX tab="settings" back title="Ajustes" sub="PEDRO DEBIZE · KYC BÁSICO">
      <div style={{padding:'0 16px 16px', overflow:'auto', height:'100%'}}>
        {/* profile */}
        <div style={{
          padding:'14px 16px', borderRadius:18, marginBottom:14,
          background:`linear-gradient(135deg, ${X.cyan}11 0%, ${X.surface} 100%)`,
          border:`1px solid ${X.hairline}`,
          display:'flex', alignItems:'center', gap:14,
        }}>
          <div style={{
            width:56, height:56, borderRadius:'50%',
            background:`linear-gradient(135deg, ${X.cyan}, ${X.neon})`,
            display:'flex', alignItems:'center', justifyContent:'center',
            color:'#000', fontSize:20, fontWeight:700,
            boxShadow:`0 0 20px ${X.cyanGlow}`,
          }}>PD</div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{fontSize:16, fontWeight:700, color:X.ink}}>Pedro Debize</div>
            <MX size={11}>plim:1a8f…3c2e · 🇵🇹 PT residente</MX>
            <div style={{marginTop:4, display:'flex', gap:6}}>
              <AcPill>KYC BÁSICO ✓</AcPill>
              <AcPill color={X.orange} bg={X.orangeSoft}>↑ ENHANCED</AcPill>
            </div>
          </div>
        </div>

        <Section title="CONTA">
          <Item2 icon="◉" label="Nome e perfil" value="Pedro Debize"/>
          <Item2 icon="◈" label="KYC" value="Básico · upgrade"/>
          <Item2 icon="⌖" label="Jurisdição" value="🇵🇹 Portugal" last/>
        </Section>

        <Section title="WALLET">
          <Item2 icon="€" label="Moeda preferida" value="EUR"/>
          <Item2 icon="◑" label="Tema" value="Sistema · escuro"/>
          <Item2 icon="A文" label="Idioma" value="Português"/>
          <Item2 icon="⚏" label="Precisão · saldos" value="Compacta" last/>
        </Section>

        <Section title="NOTIFICAÇÕES">
          <Item2 icon="●" label="Críticas · sempre" toggle={true}/>
          <Item2 icon="◐" label="Pagamentos recebidos" toggle={true}/>
          <Item2 icon="◇" label="Decisões de agentes" toggle={true}/>
          <Item2 icon="≋" label="L99 / mesh" toggle={false}/>
          <Item2 icon="↑" label="Sugestões de upgrade" toggle={false} last/>
        </Section>

        <Section title="PRIVACIDADE & DADOS">
          <Item2 icon="⤓" label="Exportar meus dados"/>
          <Item2 icon="∅" label="Telemetria anônima" toggle={false}/>
          <Item2 icon="⌫" label="Apagar conta · GDPR Art. 17" danger last/>
        </Section>

        <Section title="SOBRE">
          <Item2 icon="ⓘ" label="Versão" value="v0.4.1 · a8f3c2"/>
          <Item2 icon="◳" label="Auditoria · build" value="reproducible"/>
          <Item2 icon="⚏" label="Código aberto · GitHub" last/>
        </Section>

        <div style={{textAlign:'center', padding:'8px 0 0'}}>
          <MX size={10} dim>desbloqueado para 7 toques em "v0.4.1" → dev tools</MX>
        </div>
      </div>
    </ShX>
  );
}

// ═══════════════ ANALYTICS ═══════════════
function W_Analytics() {
  return (
    <ShX back title="Insights" sub="ÚLT. 30 DIAS · MAIO 2026">
      <div style={{padding:'0 16px 16px', overflow:'auto', height:'100%'}}>
        {/* range chips */}
        <div style={{display:'flex', gap:6, marginBottom:12}}>
          {['7d','30d','90d','12m','Tudo'].map((r, i) => (
            <div key={r} style={{
              padding:'5px 12px', borderRadius:999,
              background: i===1 ? X.neon : X.surface, color: i===1 ? '#001a08' : X.inkDim,
              border:`1px solid ${i===1 ? X.neon : X.hairline}`,
              fontSize:10, fontWeight:700, fontFamily:X.mono,
              boxShadow: i===1 ? `0 0 12px ${X.neonGlow}` : 'none',
            }}>{r}</div>
          ))}
        </div>

        {/* totals row */}
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:14}}>
          {[
            ['ENTRADAS',   '€3.247,12', '+18% vs mês ant.', X.neon],
            ['SAÍDAS',     '€1.842,40', '-4% vs mês ant.',  X.orange],
            ['DECISÕES IA','47',        '12 agentes únicos', X.cyan],
            ['CUSTO RAIL', '€2,14',     '0,12% efetivo',    X.ink],
          ].map(([k,v,sub,c],i)=>(
            <div key={i} style={{
              padding:'12px 12px', borderRadius:12,
              background:X.surface, border:`1px solid ${X.hairline}`,
            }}>
              <MX size={9} dim>{k}</MX>
              <div style={{fontSize:18, fontWeight:700, color:c, fontFamily:X.mono, marginTop:4, letterSpacing:-0.5}}>{v}</div>
              <MX size={9}>{sub}</MX>
            </div>
          ))}
        </div>

        {/* spending by category — donut */}
        <div style={{
          padding:'14px 14px', borderRadius:16, marginBottom:12,
          background:X.surface, border:`1px solid ${X.hairline}`,
        }}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10}}>
            <div>
              <div style={{fontSize:13, fontWeight:600, color:X.ink}}>Gastos por categoria</div>
              <MX size={10}>€1.842,40 · 30 dias</MX>
            </div>
            <MX size={10} color={X.neon}>VER →</MX>
          </div>
          <div style={{display:'flex', alignItems:'center', gap:14}}>
            {/* donut */}
            <div style={{position:'relative', width:110, height:110, flexShrink:0}}>
              <svg width="110" height="110" viewBox="0 0 110 110" style={{transform:'rotate(-90deg)'}}>
                <circle cx="55" cy="55" r="40" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="12"/>
                {/* segments: 42% neon, 28% orange, 18% cyan, 12% violet */}
                {[
                  [42, X.neon, 0],
                  [28, X.orange, 42],
                  [18, X.cyan, 70],
                  [12, '#C792FF', 88],
                ].map(([pct, c, start], i) => (
                  <circle key={i} cx="55" cy="55" r="40" fill="none" stroke={c} strokeWidth="12"
                          strokeDasharray={`${2*Math.PI*40*pct/100} ${2*Math.PI*40}`}
                          strokeDashoffset={`${-2*Math.PI*40*start/100}`}
                          strokeLinecap="butt"/>
                ))}
              </svg>
              <div style={{position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center'}}>
                <div style={{fontSize:14, fontWeight:700, color:X.ink, fontFamily:X.mono}}>€1.84k</div>
                <MX size={8} dim>TOTAL</MX>
              </div>
            </div>
            <div style={{flex:1, display:'flex', flexDirection:'column', gap:8}}>
              {[
                ['Negócios · B2AI',  '€774', '42%', X.neon],
                ['Agente · AI2AI',   '€516', '28%', X.orange],
                ['Pessoas · P2AI',   '€332', '18%', X.cyan],
                ['Gov · G2AI',       '€221', '12%', '#C792FF'],
              ].map(([k, v, p, c], i) => (
                <div key={i} style={{display:'flex', alignItems:'center', gap:8}}>
                  <div style={{width:8, height:8, borderRadius:2, background:c}}/>
                  <div style={{flex:1, fontSize:11, color:X.ink}}>{k}</div>
                  <div style={{fontSize:11, color:X.inkDim, fontFamily:X.mono}}>{v} · {p}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* rail efficiency bars */}
        <div style={{
          padding:'14px 14px', borderRadius:16, marginBottom:12,
          background:X.surface, border:`1px solid ${X.hairline}`,
        }}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:12}}>
            <div>
              <div style={{fontSize:13, fontWeight:600, color:X.ink}}>Eficiência por rail</div>
              <MX size={10}>custo médio · últimos 30d</MX>
            </div>
            <MX size={10} color={X.neon}>P:L:I:M MAIS BARATO</MX>
          </div>
          <div style={{display:'flex', flexDirection:'column', gap:10}}>
            {[
              ['P:L:I:M',  '€0,00012', 0.05,  X.neon,   '23 tx'],
              ['SEPA',     '€0,02',    0.30,  X.cyan,   '14 tx'],
              ['L99 mesh', '€0,00',    0.10,  X.neon,   '3 tx · offline'],
              ['Stripe',   '€0,21',    0.95,  X.orange, '7 tx'],
              ['USDC L2',  '€0,08',    0.55,  X.cyan,   '2 tx'],
            ].map(([n,v,w,c,detail],i)=>(
              <div key={i}>
                <div style={{display:'flex', alignItems:'baseline', justifyContent:'space-between'}}>
                  <div style={{fontSize:11, color:X.ink, fontWeight:600, fontFamily:X.mono}}>{n}</div>
                  <div style={{display:'flex', gap:8}}>
                    <MX size={9} dim>{detail}</MX>
                    <div style={{fontSize:11, color:c, fontFamily:X.mono, fontWeight:600, width:60, textAlign:'right'}}>{v}</div>
                  </div>
                </div>
                <div style={{marginTop:3, height:5, borderRadius:3, background:'rgba(255,255,255,0.06)', overflow:'hidden'}}>
                  <div style={{width:`${w*100}%`, height:'100%', background:c, boxShadow:`0 0 6px ${c}66`}}/>
                </div>
              </div>
            ))}
          </div>
          <div style={{
            marginTop:12, padding:'8px 10px', borderRadius:8,
            background:`${X.neon}10`, border:`1px solid ${X.neon}33`,
          }}>
            <MX size={10} color={X.neon}>
              💡 Você economizou <span style={{fontWeight:700}}>€4,32</span> usando P:L:I:M em vez de Stripe.
            </MX>
          </div>
        </div>

        {/* monthly trend */}
        <div style={{
          padding:'14px 14px', borderRadius:16,
          background:X.surface, border:`1px solid ${X.hairline}`,
        }}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8}}>
            <div style={{fontSize:13, fontWeight:600, color:X.ink}}>Fluxo · 30 dias</div>
            <MX size={10} color={X.neon}>+ €1.404,72 líquido</MX>
          </div>
          <svg width="100%" height="80" viewBox="0 0 320 80" preserveAspectRatio="none">
            <defs>
              <linearGradient id="flowGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={X.neon} stopOpacity="0.5"/>
                <stop offset="100%" stopColor={X.neon} stopOpacity="0"/>
              </linearGradient>
            </defs>
            <path d="M0,60 L20,55 L40,58 L60,40 L80,45 L100,32 L120,38 L140,28 L160,30 L180,22 L200,38 L220,18 L240,24 L260,12 L280,22 L300,10 L320,14 L320,80 L0,80 Z"
                  fill="url(#flowGrad)"/>
            <path d="M0,60 L20,55 L40,58 L60,40 L80,45 L100,32 L120,38 L140,28 L160,30 L180,22 L200,38 L220,18 L240,24 L260,12 L280,22 L300,10 L320,14"
                  stroke={X.neon} strokeWidth="2" fill="none"
                  style={{filter:`drop-shadow(0 0 4px ${X.neonGlow})`}}/>
          </svg>
          <div style={{display:'flex', justifyContent:'space-between', marginTop:4}}>
            <MX size={9} dim>15 ABR</MX>
            <MX size={9} dim>30 ABR</MX>
            <MX size={9} dim>14 MAI</MX>
          </div>
        </div>
      </div>
    </ShX>
  );
}

Object.assign(window, { W_Security, W_Settings, W_Analytics });
