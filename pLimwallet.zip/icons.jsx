// icons.jsx — pLim icon set. Single <Icon name size color stroke/> entry.
// Stroke-based, 24×24 viewBox, square-cap. Built for 2026 iOS aesthetic.

const ICON_PATHS = {
  // navigation
  'chevron-left':   <path d="M15 5l-7 7 7 7"/>,
  'chevron-right':  <path d="M9 5l7 7-7 7"/>,
  'chevron-down':   <path d="M5 9l7 7 7-7"/>,
  'chevron-up':     <path d="M5 15l7-7 7 7"/>,
  'close':          <><path d="M6 6l12 12"/><path d="M18 6l-12 12"/></>,
  'check':          <path d="M5 12l5 5 9-11"/>,
  'more':           <><circle cx="6" cy="12" r="1.5" fill="currentColor"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/><circle cx="18" cy="12" r="1.5" fill="currentColor"/></>,

  // wallet primary actions
  'arrow-up':       <><path d="M12 19V5"/><path d="M5 12l7-7 7 7"/></>,
  'arrow-down':     <><path d="M12 5v14"/><path d="M5 12l7 7 7-7"/></>,
  'send':           <><path d="M21 3L10.5 13.5"/><path d="M21 3l-7 18-4-9-9-4 20-5z"/></>,
  'receive':        <><path d="M12 5v14"/><path d="M5 12l7 7 7-7"/></>,
  'swap':           <><path d="M7 4v16"/><path d="M3 8l4-4 4 4"/><path d="M17 20V4"/><path d="M21 16l-4 4-4-4"/></>,
  'scan':           <><path d="M3 8V5a2 2 0 012-2h3"/><path d="M21 8V5a2 2 0 00-2-2h-3"/><path d="M3 16v3a2 2 0 002 2h3"/><path d="M21 16v3a2 2 0 01-2 2h-3"/><path d="M7 12h10"/></>,
  'qr':             <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3M14 21h7M21 14v7M17 17v1"/></>,
  'copy':           <><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 012-2h9"/></>,
  'share':          <><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></>,
  'plus':           <><path d="M12 5v14"/><path d="M5 12h14"/></>,
  'add':            <><circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/></>,

  // status & feedback
  'check-circle':   <><circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/></>,
  'info':           <><circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><circle cx="12" cy="8" r="0.5" fill="currentColor"/></>,
  'warning':        <><path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5"/><circle cx="12" cy="18" r="0.5" fill="currentColor"/></>,
  'alert':          <><circle cx="12" cy="12" r="9"/><path d="M12 7v6"/><circle cx="12" cy="16.5" r="0.5" fill="currentColor"/></>,
  'shield':         <path d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6l8-3z"/>,
  'shield-check':   <><path d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/></>,

  // identity & security
  'key':            <><circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/></>,
  'lock':           <><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></>,
  'unlock':         <><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 017-2.6"/></>,
  'face-id':        <><path d="M4 8V6a2 2 0 012-2h2M20 8V6a2 2 0 00-2-2h-2M4 16v2a2 2 0 002 2h2M20 16v2a2 2 0 01-2 2h-2"/><path d="M9 10v2M15 10v2M10 16c1 1 3 1 4 0"/></>,
  'fingerprint':    <><path d="M5 12a7 7 0 0114 0v2"/><path d="M9 12a3 3 0 016 0v3a4 4 0 01-2 3.5"/><path d="M15 19c-2 1-5 1-7 0"/></>,
  'user':           <><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-7 8-7s8 3 8 7"/></>,
  'users':          <><circle cx="9" cy="8" r="4"/><path d="M2 21c0-4 3-7 7-7s7 3 7 7"/><path d="M16 4a4 4 0 010 8M17 14c3 .5 5 3 5 7"/></>,

  // payment / money
  'wallet':         <><rect x="3" y="6" width="18" height="14" rx="3"/><path d="M16 13h2M3 10h15"/></>,
  'card':           <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/></>,
  'coin':           <><circle cx="12" cy="12" r="9"/><path d="M9 10c0-1.5 1.5-2 3-2s3 .5 3 2-1.5 2-3 2-3 .5-3 2 1.5 2 3 2 3-.5 3-2M12 6v2M12 16v2"/></>,
  'euro':           <><path d="M18 7a7 7 0 100 10"/><path d="M3 10h11M3 14h11"/></>,
  'bank':           <><path d="M3 9L12 4l9 5"/><path d="M5 9v9M9 9v9M15 9v9M19 9v9M3 21h18"/></>,

  // mesh & connectivity
  'wifi':           <><path d="M5 12a10 10 0 0114 0"/><path d="M8.5 15.5a5 5 0 017 0"/><circle cx="12" cy="19" r="0.5" fill="currentColor"/></>,
  'wifi-off':       <><path d="M5 12a10 10 0 014.5-2.7M19 12a10 10 0 00-3-1.7"/><path d="M9 15.5a5 5 0 015-.4M3 3l18 18"/></>,
  'signal':         <><path d="M3 18h2M8 14h2M13 10h2M18 6h2"/><path d="M3 18v3M8 14v7M13 10v11M18 6v15"/></>,
  'bluetooth':      <path d="M7 7l10 10-5 4V3l5 4L7 17"/>,
  'broadcast':      <><circle cx="12" cy="12" r="2"/><path d="M8.5 8.5a5 5 0 000 7M15.5 15.5a5 5 0 000-7"/><path d="M5.5 5.5a9 9 0 000 13M18.5 18.5a9 9 0 000-13"/></>,
  'mesh':           <><circle cx="12" cy="12" r="2"/><circle cx="4" cy="6" r="1.5"/><circle cx="20" cy="6" r="1.5"/><circle cx="4" cy="18" r="1.5"/><circle cx="20" cy="18" r="1.5"/><path d="M5 7l6 4M19 7l-6 4M5 17l6-4M19 17l-6-4"/></>,
  'battery':        <><rect x="2" y="8" width="18" height="8" rx="2"/><rect x="4" y="10" width="13" height="4" rx="0.5" fill="currentColor"/><path d="M22 11v2"/></>,
  'solar':          <><circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/></>,

  // ai / agent
  'sparkle':        <path d="M12 3l1.5 5L18 9.5 13.5 11 12 16l-1.5-5L6 9.5 10.5 8 12 3z"/>,
  'agent':          <><circle cx="12" cy="12" r="9"/><circle cx="9" cy="11" r="1" fill="currentColor"/><circle cx="15" cy="11" r="1" fill="currentColor"/><path d="M9 16c1.5 1.2 4.5 1.2 6 0"/><path d="M12 3v2M5 5l1.5 1.5M19 5l-1.5 1.5"/></>,
  'cpu':            <><rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 3v2M15 3v2M9 19v2M15 19v2M3 9h2M3 15h2M19 9h2M19 15h2"/></>,

  // misc
  'search':         <><circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5"/></>,
  'filter':         <path d="M3 6h18l-7 9v5l-4-2v-3L3 6z"/>,
  'download':       <><path d="M12 4v12"/><path d="M5 11l7 7 7-7"/><path d="M4 20h16"/></>,
  'upload':         <><path d="M12 4v12"/><path d="M5 11l7-7 7 7"/><path d="M4 20h16"/></>,
  'settings':       <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.4 1.8l.1.1a2 2 0 01-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.4 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.4l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.4-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.4-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.4H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.4l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.4 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/></>,
  'home':           <><path d="M3 11l9-8 9 8v9a2 2 0 01-2 2h-3v-7H8v7H5a2 2 0 01-2-2v-9z"/></>,
  'list':           <><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1" fill="currentColor"/><circle cx="3.5" cy="12" r="1" fill="currentColor"/><circle cx="3.5" cy="18" r="1" fill="currentColor"/></>,
  'grid':           <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
  'eye':            <><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></>,
  'eye-off':        <><path d="M3 3l18 18M10.6 6.1A10 10 0 0112 6c6 0 10 6 10 6a13 13 0 01-3 3.6M6 7.5A13 13 0 002 12s4 6 10 6a9 9 0 003.9-.9"/><path d="M9.9 9.9a3 3 0 004.2 4.2"/></>,
  'bell':           <><path d="M6 8a6 6 0 1112 0c0 6 3 8 3 8H3s3-2 3-8z"/><path d="M10 21h4"/></>,
  'clock':          <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  'globe':          <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/></>,
  'flame':          <path d="M12 3c2 4 6 5 6 10a6 6 0 01-12 0c0-2 1-3.5 2.5-5C9 9.5 11 7.5 12 3z"/>,
  'pause':          <><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></>,
  'trash':          <><path d="M4 7h16M10 11v6M14 11v6"/><path d="M5 7l1 13a2 2 0 002 2h8a2 2 0 002-2l1-13"/><path d="M9 7V4a1 1 0 011-1h4a1 1 0 011 1v3"/></>,
  'circuit':        <><circle cx="6" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="M6 8v4a2 2 0 002 2h4a2 2 0 012 2v2"/></>,
  'route':          <><circle cx="5" cy="6" r="3"/><circle cx="19" cy="18" r="3"/><path d="M5 9v6a3 3 0 003 3h2a3 3 0 003-3v-4a3 3 0 013-3h3"/></>,
};

function Icon({ name, size = 20, color = 'currentColor', stroke = 1.75, fill = 'none', style }) {
  const content = ICON_PATHS[name];
  if (!content) return null;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={color}
         strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
         style={{display:'inline-block', flexShrink:0, ...style}}>
      {content}
    </svg>
  );
}

window.Icon = Icon;
