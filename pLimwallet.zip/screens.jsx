// pLim wallet — onboarding screens
// Visual language: deep black canvas, neon-green primary (#39FF7A) with bloom,
// orange accent (#FF6A1A), grid lines & terminal-mono for protocol vibes,
// SF for body. All copy in PT-BR (per project context).

const PLIM = {
  bg:        '#06090A',
  surface:   '#0E1311',
  surface2:  '#161C19',
  hairline:  'rgba(180,255,200,0.10)',
  ink:       '#E8FFEA',
  inkDim:    'rgba(232,255,234,0.62)',
  inkFaint:  'rgba(232,255,234,0.32)',
  neon:      '#39FF7A',
  neonSoft:  'rgba(57,255,122,0.18)',
  neonGlow:  'rgba(57,255,122,0.55)',
  orange:    '#FF6A1A',
  orangeSoft:'rgba(255,106,26,0.16)',
  cyan:      '#1FC8E8',           // brand cyan from official logo
  cyanGlow:  'rgba(31,200,232,0.55)',
  red:       '#FF4D5E',
  mono:      '"JetBrains Mono", "SF Mono", ui-monospace, monospace',
  logoSrc:   'assets/plim-logo.png',
};

// ───────── Shared primitives ─────────
const Grid = () => (
  <div style={{
    position:'absolute', inset:0, pointerEvents:'none',
    backgroundImage:
      'linear-gradient(rgba(57,255,122,0.04) 1px, transparent 1px),'+
      'linear-gradient(90deg, rgba(57,255,122,0.04) 1px, transparent 1px)',
    backgroundSize:'24px 24px',
    maskImage:'radial-gradient(ellipse at 50% 30%, #000 30%, transparent 75%)',
    WebkitMaskImage:'radial-gradient(ellipse at 50% 30%, #000 30%, transparent 75%)',
  }} />
);

const Logo = ({ size = 48, glow = true }) => (
  <div style={{
    width:size, height:size, position:'relative',
    display:'flex', alignItems:'center', justifyContent:'center',
  }}>
    {glow && <div style={{
      position:'absolute', inset:-size*0.35,
      background:`radial-gradient(circle, ${PLIM.cyanGlow} 0%, transparent 60%)`,
      filter:'blur(10px)',
    }} />}
    <img src={PLIM.logoSrc} alt="pLim"
         draggable={false}
         style={{
           width:size, height:size, objectFit:'contain',
           position:'relative',
           filter: glow ? `drop-shadow(0 0 8px ${PLIM.cyanGlow})` : 'none',
         }} />
  </div>
);

// iOS app icon — rounded squircle, branded dark backdrop, logo centered.
// Default 180×180 = iOS @3x app icon size.
const AppIcon = ({ size = 180, glow = true }) => (
  <div style={{
    width:size, height:size,
    borderRadius: size * 0.225, // iOS continuous corner ratio
    position:'relative', overflow:'hidden',
    background:
      `radial-gradient(circle at 30% 25%, ${PLIM.cyan}25 0%, transparent 55%),`+
      `radial-gradient(circle at 75% 80%, ${PLIM.neon}18 0%, transparent 55%),`+
      `linear-gradient(160deg, #0a1418 0%, #050708 100%)`,
    boxShadow: glow
      ? `0 0 0 1px rgba(255,255,255,0.06), 0 ${size*0.08}px ${size*0.2}px rgba(0,0,0,0.6), 0 0 ${size*0.25}px ${PLIM.cyanGlow}`
      : `0 0 0 1px rgba(255,255,255,0.08), 0 ${size*0.04}px ${size*0.1}px rgba(0,0,0,0.4)`,
    display:'flex', alignItems:'center', justifyContent:'center',
  }}>
    {/* subtle circuit grid */}
    <div style={{
      position:'absolute', inset:0,
      backgroundImage:
        `linear-gradient(${PLIM.cyan}10 1px, transparent 1px),`+
        `linear-gradient(90deg, ${PLIM.cyan}10 1px, transparent 1px)`,
      backgroundSize: `${size*0.06}px ${size*0.06}px`,
      maskImage:'radial-gradient(circle at 50% 50%, #000 30%, transparent 80%)',
      WebkitMaskImage:'radial-gradient(circle at 50% 50%, #000 30%, transparent 80%)',
    }} />
    {/* logo glow halo */}
    <div style={{
      position:'absolute', inset:'15%',
      background:`radial-gradient(circle, ${PLIM.cyanGlow} 0%, transparent 65%)`,
      filter:'blur(12px)',
      opacity:0.7,
    }} />
    <img src={PLIM.logoSrc} alt="pLim"
         draggable={false}
         style={{
           width: size * 0.78, height: size * 0.78,
           objectFit:'contain', position:'relative',
           filter:`drop-shadow(0 0 ${size*0.04}px ${PLIM.cyanGlow})`,
         }} />
    {/* inner highlight */}
    <div style={{
      position:'absolute', inset:0, borderRadius:'inherit',
      boxShadow:`inset 0 1px 0 rgba(255,255,255,0.12), inset 0 -1px 0 rgba(0,0,0,0.4)`,
      pointerEvents:'none',
    }} />
  </div>
);

const Wordmark = ({ size = 22 }) => (
  <div style={{
    fontFamily: PLIM.mono, fontWeight:600, fontSize:size, letterSpacing: -0.5,
    color: PLIM.ink, display:'inline-flex', alignItems:'center', gap:2,
  }}>
    p<span style={{color:PLIM.neon, textShadow:`0 0 12px ${PLIM.neonGlow}`}}>Lim</span>
  </div>
);

const Pill = ({ children, color = PLIM.neon, bg = PLIM.neonSoft }) => (
  <span style={{
    display:'inline-flex', alignItems:'center', gap:6,
    padding:'4px 9px', borderRadius:999,
    background:bg, color, fontFamily:PLIM.mono, fontSize:10, fontWeight:600,
    letterSpacing:0.6, textTransform:'uppercase',
    border:`1px solid ${color}33`,
  }}>{children}</span>
);

const Btn = ({ children, variant='primary', icon, sub }) => {
  const styles = {
    primary: {
      background: PLIM.neon, color:'#001a08',
      boxShadow:`0 0 24px ${PLIM.neonGlow}, inset 0 1px 0 rgba(255,255,255,0.4)`,
    },
    orange: {
      background: PLIM.orange, color:'#1a0a00',
      boxShadow:`0 0 22px rgba(255,106,26,0.45), inset 0 1px 0 rgba(255,255,255,0.3)`,
    },
    ghost: {
      background:'transparent', color:PLIM.ink,
      border:`1px solid ${PLIM.hairline}`,
    },
    dark: {
      background: PLIM.surface, color:PLIM.ink,
      border:`1px solid ${PLIM.hairline}`,
    },
  }[variant];
  return (
    <div style={{
      ...styles,
      height: sub ? 60 : 52, borderRadius: 16,
      display:'flex', alignItems:'center', justifyContent:'center',
      padding:'0 18px', gap:10,
      fontFamily:'-apple-system, system-ui', fontWeight:600, fontSize:16,
      letterSpacing:-0.2,
    }}>
      {icon}
      {sub ? (
        <div style={{display:'flex', flexDirection:'column', alignItems:'flex-start', lineHeight:1.15}}>
          <div>{children}</div>
          <div style={{fontSize:11, fontWeight:500, opacity:0.7, fontFamily:PLIM.mono}}>{sub}</div>
        </div>
      ) : children}
    </div>
  );
};

const StepDots = ({ step, total = 6 }) => (
  <div style={{display:'flex', gap:6, justifyContent:'center', padding:'12px 0'}}>
    {Array.from({length: total}).map((_, i) => (
      <div key={i} style={{
        height:3, borderRadius:2,
        width: i === step ? 22 : 8,
        background: i <= step ? PLIM.neon : 'rgba(255,255,255,0.12)',
        boxShadow: i === step ? `0 0 8px ${PLIM.neonGlow}` : 'none',
        transition:'all .3s',
      }} />
    ))}
  </div>
);

// ═══════════════ SCREEN 1 — Splash / Welcome ═══════════════
function S1_Welcome() {
  return (
    <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden'}}>
      <Grid/>
      {/* big radial glow — cyan from brand + green halo */}
      <div style={{
        position:'absolute', top:'-20%', left:'-30%', right:'-30%', height:'70%',
        background:`radial-gradient(ellipse, ${PLIM.cyanGlow} 0%, transparent 60%)`,
        filter:'blur(40px)', opacity:0.45,
      }}/>
      <div style={{
        position:'absolute', bottom:'-20%', left:'-30%', right:'-30%', height:'50%',
        background:`radial-gradient(ellipse, ${PLIM.neonGlow} 0%, transparent 60%)`,
        filter:'blur(50px)', opacity:0.35,
      }}/>
      <div style={{position:'absolute', inset:0, display:'flex', flexDirection:'column', padding:'80px 28px 36px'}}>
        {/* upper section */}
        <div style={{flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:28}}>
          <AppIcon size={132}/>
          <div style={{textAlign:'center'}}>
            <Wordmark size={42}/>
            <div style={{
              fontFamily:PLIM.mono, fontSize:11, color:PLIM.inkDim, letterSpacing:3,
              marginTop:8, textTransform:'uppercase',
            }}>peer · ledger · intent · mesh</div>
          </div>
          <div style={{
            fontSize:18, lineHeight:1.4, textAlign:'center', color:PLIM.ink,
            maxWidth:280, fontWeight:400, letterSpacing:-0.3,
          }}>
            Sua carteira <span style={{color:PLIM.neon}}>resiliente</span> —<br/>
            funciona <span style={{color:PLIM.orange}}>sem internet</span>, sem servidor, sem permissão.
          </div>
          {/* status chips */}
          <div style={{display:'flex', gap:6, flexWrap:'wrap', justifyContent:'center'}}>
            <Pill>● P2P MESH</Pill>
            <Pill color={PLIM.orange} bg={PLIM.orangeSoft}>● LORA / BLE</Pill>
            <Pill>● AI2AI</Pill>
          </div>
        </div>
        {/* CTA */}
        <div style={{display:'flex', flexDirection:'column', gap:12}}>
          <Btn variant="primary" icon={<span style={{fontFamily:PLIM.mono}}>+</span>}>Criar nova wallet</Btn>
          <Btn variant="ghost">Já tenho uma seed</Btn>
        </div>
      </div>
    </div>
  );
}

// ═══════════════ SCREEN 2 — Choose path ═══════════════
function S2_Path() {
  const Row = ({ icon, title, sub, badge, accent = PLIM.neon, recommended }) => (
    <div style={{
      position:'relative',
      background: PLIM.surface,
      border:`1px solid ${recommended ? accent+'55' : PLIM.hairline}`,
      borderRadius:18, padding:'16px 16px', display:'flex', gap:14, alignItems:'center',
      boxShadow: recommended ? `0 0 0 1px ${accent}22, 0 0 24px ${accent}22` : 'none',
    }}>
      <div style={{
        width:44, height:44, borderRadius:12, flexShrink:0,
        background:`${accent}18`, color:accent,
        display:'flex', alignItems:'center', justifyContent:'center',
        fontFamily:PLIM.mono, fontSize:22, fontWeight:600,
        border:`1px solid ${accent}33`,
      }}>{icon}</div>
      <div style={{flex:1, minWidth:0}}>
        <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:2}}>
          <div style={{fontSize:15, fontWeight:600, color:PLIM.ink}}>{title}</div>
          {badge && <Pill color={accent} bg={`${accent}18`}>{badge}</Pill>}
        </div>
        <div style={{fontSize:12, color:PLIM.inkDim, lineHeight:1.4}}>{sub}</div>
      </div>
      <div style={{color:PLIM.inkFaint, fontSize:18}}>›</div>
    </div>
  );
  return (
    <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden'}}>
      <Grid/>
      <div style={{position:'absolute', inset:0, padding:'72px 24px 32px', display:'flex', flexDirection:'column'}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:24}}>
          <div style={{color:PLIM.inkDim, fontSize:15}}>‹ Voltar</div>
          <div style={{fontFamily:PLIM.mono, fontSize:10, color:PLIM.inkFaint, letterSpacing:1.5}}>01 / 06</div>
        </div>
        <div style={{fontSize:30, fontWeight:700, letterSpacing:-0.8, lineHeight:1.1, marginBottom:8}}>
          Como você quer<br/>começar?
        </div>
        <div style={{fontSize:14, color:PLIM.inkDim, marginBottom:24, lineHeight:1.45}}>
          Sua chave nunca sai do dispositivo. Escolha uma origem.
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:10, flex:1}}>
          <Row icon="+" title="Criar nova wallet" sub="Gere 12 palavras locais no Secure Enclave"
               badge="Recomendado" recommended/>
          <Row icon="↺" title="Restaurar com seed" sub="12 ou 24 palavras BIP-39"/>
          <Row icon="⟷" title="Parear com node" sub="Importe de um pLim/node próximo via BLE"
               accent={PLIM.orange}/>
          <Row icon="⌨" title="Hardware wallet" sub="Ledger / Trezor — disponível em breve" accent={PLIM.inkFaint}/>
        </div>
        <StepDots step={0}/>
      </div>
    </div>
  );
}

// ═══════════════ SCREEN 3 — Privacy primer ═══════════════
function S3_Privacy() {
  const Feature = ({ glyph, title, body, color = PLIM.neon }) => (
    <div style={{display:'flex', gap:14, alignItems:'flex-start'}}>
      <div style={{
        width:38, height:38, borderRadius:10, flexShrink:0, marginTop:2,
        background:`${color}14`, border:`1px solid ${color}33`,
        display:'flex', alignItems:'center', justifyContent:'center',
        color, fontSize:18,
      }}>{glyph}</div>
      <div>
        <div style={{fontSize:15, fontWeight:600, color:PLIM.ink, marginBottom:3}}>{title}</div>
        <div style={{fontSize:13, color:PLIM.inkDim, lineHeight:1.45}}>{body}</div>
      </div>
    </div>
  );
  return (
    <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden'}}>
      <Grid/>
      <div style={{position:'absolute', inset:0, padding:'72px 24px 32px', display:'flex', flexDirection:'column'}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:18}}>
          <div style={{color:PLIM.inkDim, fontSize:15}}>‹</div>
          <div style={{fontFamily:PLIM.mono, fontSize:10, color:PLIM.inkFaint, letterSpacing:1.5}}>02 / 06</div>
        </div>
        {/* hero visual — orbiting node graph */}
        <div style={{position:'relative', height:160, marginBottom:18}}>
          <div style={{position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center'}}>
            <Logo size={68}/>
          </div>
          {/* orbit rings */}
          {[60, 95, 130].map((r, i) => (
            <div key={i} style={{
              position:'absolute', top:'50%', left:'50%',
              width:r*2, height:r*2, marginLeft:-r, marginTop:-r,
              border:`1px dashed ${i===1 ? PLIM.orange+'55' : PLIM.neon+'33'}`,
              borderRadius:'50%',
            }}/>
          ))}
          {/* nodes */}
          {[
            [50,32,PLIM.neon],[290,46,PLIM.neon],[40,110,PLIM.orange],
            [310,128,PLIM.orange],[180,8,PLIM.neon],[180,154,PLIM.neon],
          ].map(([x,y,c],i)=>(
            <div key={i} style={{
              position:'absolute', left:x, top:y, width:8, height:8, borderRadius:'50%',
              background:c, boxShadow:`0 0 12px ${c}`,
            }}/>
          ))}
        </div>
        <div style={{fontSize:26, fontWeight:700, letterSpacing:-0.6, marginBottom:6, lineHeight:1.15}}>
          Privacidade<br/>por arquitetura
        </div>
        <div style={{fontSize:13, color:PLIM.inkDim, marginBottom:22, lineHeight:1.45}}>
          pLim foi desenhado para operar quando tudo o mais falha.
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:18, flex:1}}>
          <Feature glyph="◈" title="Chave no Secure Enclave"
            body="A chave privada nunca toca a memória do app. Assinatura via TEE/Secure Enclave."/>
          <Feature glyph="≋" title="Roteamento em mesh" color={PLIM.orange}
            body="Pagamentos saltam por BLE, Wi-Fi Direct e LoRa. Sem servidor, sem internet obrigatória."/>
          <Feature glyph="∅" title="Zero telemetria"
            body="Nada de logs, sem analytics. Verificável — código auditável open source."/>
        </div>
        <Btn variant="primary">Entendi, continuar</Btn>
        <StepDots step={1}/>
      </div>
    </div>
  );
}

// ═══════════════ SCREEN 4 — Set passcode ═══════════════
function S4_Passcode() {
  const dots = [1,1,1,1,0,0]; // 4 entered of 6
  const Key = ({ n, sub }) => (
    <div style={{
      height:60, borderRadius:18, background:PLIM.surface,
      border:`1px solid ${PLIM.hairline}`,
      display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
      color:PLIM.ink, fontSize:26, fontWeight:500, fontFamily:'-apple-system',
    }}>
      <div>{n}</div>
      {sub && <div style={{fontSize:8, color:PLIM.inkDim, letterSpacing:2, marginTop:-2}}>{sub}</div>}
    </div>
  );
  return (
    <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden'}}>
      <Grid/>
      <div style={{position:'absolute', inset:0, padding:'72px 24px 24px', display:'flex', flexDirection:'column'}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:36}}>
          <div style={{color:PLIM.inkDim, fontSize:15}}>‹</div>
          <div style={{fontFamily:PLIM.mono, fontSize:10, color:PLIM.inkFaint, letterSpacing:1.5}}>03 / 06</div>
        </div>
        <div style={{textAlign:'center', marginBottom:8}}>
          <div style={{
            width:54, height:54, borderRadius:14, margin:'0 auto 16px',
            background:PLIM.neonSoft, border:`1px solid ${PLIM.neon}55`,
            display:'flex', alignItems:'center', justifyContent:'center',
            color:PLIM.neon, fontSize:24, boxShadow:`0 0 24px ${PLIM.neonGlow}`,
          }}>◉</div>
          <div style={{fontSize:26, fontWeight:700, letterSpacing:-0.6}}>Defina seu PIN</div>
          <div style={{fontSize:13, color:PLIM.inkDim, marginTop:6, lineHeight:1.45, padding:'0 20px'}}>
            6 dígitos para desbloquear pagamentos locais. Funciona offline.
          </div>
        </div>
        {/* PIN dots */}
        <div style={{display:'flex', gap:14, justifyContent:'center', margin:'34px 0 18px'}}>
          {dots.map((d, i) => (
            <div key={i} style={{
              width:14, height:14, borderRadius:'50%',
              background: d ? PLIM.neon : 'transparent',
              border:`1.5px solid ${d ? PLIM.neon : 'rgba(255,255,255,0.25)'}`,
              boxShadow: d ? `0 0 10px ${PLIM.neonGlow}` : 'none',
            }}/>
          ))}
        </div>
        <div style={{
          textAlign:'center', fontFamily:PLIM.mono, fontSize:10,
          color:PLIM.neon, letterSpacing:2, marginBottom:18,
        }}>● ENCLAVE ATIVO · ENC=AES-256-GCM</div>
        {/* keypad */}
        <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:10, flex:1, alignContent:'end'}}>
          <Key n="1"/>
          <Key n="2" sub="A B C"/>
          <Key n="3" sub="D E F"/>
          <Key n="4" sub="G H I"/>
          <Key n="5" sub="J K L"/>
          <Key n="6" sub="M N O"/>
          <Key n="7" sub="P Q R S"/>
          <Key n="8" sub="T U V"/>
          <Key n="9" sub="W X Y Z"/>
          <div/>
          <Key n="0"/>
          <div style={{
            height:60, display:'flex', alignItems:'center', justifyContent:'center',
            color:PLIM.inkDim, fontSize:14,
          }}>⌫</div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════ SCREEN 5 — Recovery seed ═══════════════
function S5_Seed() {
  const words = ['mesh','solar','ember','copper','quartz','horizon',
                 'lattice','signal','ember','drift','beacon','orbit'];
  return (
    <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden'}}>
      <Grid/>
      <div style={{position:'absolute', inset:0, padding:'72px 24px 28px', display:'flex', flexDirection:'column'}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:18}}>
          <div style={{color:PLIM.inkDim, fontSize:15}}>‹</div>
          <div style={{fontFamily:PLIM.mono, fontSize:10, color:PLIM.inkFaint, letterSpacing:1.5}}>04 / 06</div>
        </div>
        <div style={{fontSize:26, fontWeight:700, letterSpacing:-0.6, lineHeight:1.15}}>
          Sua frase de<br/>recuperação
        </div>
        <div style={{
          marginTop:10, padding:'10px 12px', borderRadius:10,
          background:PLIM.orangeSoft, border:`1px solid ${PLIM.orange}40`,
          display:'flex', gap:10, alignItems:'flex-start',
        }}>
          <div style={{color:PLIM.orange, fontSize:14, marginTop:1}}>△</div>
          <div style={{fontSize:12, color:PLIM.ink, lineHeight:1.4}}>
            Escreva em papel. <span style={{color:PLIM.orange, fontWeight:600}}>Nunca</span> faça screenshot
            ou armazene em nuvem. Quem tem a frase tem o saldo.
          </div>
        </div>
        {/* seed grid */}
        <div style={{
          marginTop:18, padding:14, borderRadius:18,
          background:PLIM.surface, border:`1px solid ${PLIM.hairline}`,
          display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, position:'relative',
        }}>
          {words.map((w,i) => (
            <div key={i} style={{
              display:'flex', alignItems:'baseline', gap:8,
              padding:'9px 12px', background:'rgba(255,255,255,0.02)',
              borderRadius:10, border:`1px solid ${PLIM.hairline}`,
            }}>
              <span style={{fontFamily:PLIM.mono, fontSize:10, color:PLIM.inkFaint, width:14}}>
                {String(i+1).padStart(2,'0')}
              </span>
              <span style={{fontFamily:PLIM.mono, fontSize:13, color:PLIM.ink, letterSpacing:-0.3}}>
                {w}
              </span>
            </div>
          ))}
        </div>
        {/* actions row */}
        <div style={{display:'flex', gap:8, marginTop:14}}>
          <div style={{
            flex:1, height:42, borderRadius:12,
            background:PLIM.surface, border:`1px solid ${PLIM.hairline}`,
            display:'flex', alignItems:'center', justifyContent:'center', gap:8,
            color:PLIM.inkDim, fontSize:13, fontFamily:PLIM.mono,
          }}>⎘ Copiar</div>
          <div style={{
            flex:1, height:42, borderRadius:12,
            background:PLIM.surface, border:`1px solid ${PLIM.hairline}`,
            display:'flex', alignItems:'center', justifyContent:'center', gap:8,
            color:PLIM.inkDim, fontSize:13, fontFamily:PLIM.mono,
          }}>⊟ QR offline</div>
        </div>
        <div style={{flex:1}}/>
        <Btn variant="primary">Já anotei, continuar</Btn>
        <StepDots step={3}/>
      </div>
    </div>
  );
}

// ═══════════════ SCREEN 6 — Choose rails ═══════════════
function S6_Rails() {
  const Rail = ({ sym, name, sub, on, accent = PLIM.neon, locked }) => (
    <div style={{
      display:'flex', alignItems:'center', gap:12, padding:'12px 14px',
      borderRadius:14, background:PLIM.surface,
      border:`1px solid ${on ? accent+'55' : PLIM.hairline}`,
      boxShadow: on ? `0 0 0 1px ${accent}22, inset 0 0 24px ${accent}10` : 'none',
      opacity: locked ? 0.5 : 1,
    }}>
      <div style={{
        width:34, height:34, borderRadius:'50%',
        background:`${accent}18`, border:`1px solid ${accent}44`,
        color:accent, display:'flex', alignItems:'center', justifyContent:'center',
        fontFamily:PLIM.mono, fontWeight:700, fontSize:12,
      }}>{sym}</div>
      <div style={{flex:1, minWidth:0}}>
        <div style={{fontSize:14, fontWeight:600, color:PLIM.ink}}>{name}</div>
        <div style={{fontSize:11, color:PLIM.inkDim, fontFamily:PLIM.mono}}>{sub}</div>
      </div>
      {/* toggle */}
      <div style={{
        width:38, height:22, borderRadius:11, padding:2,
        background: on ? accent : 'rgba(255,255,255,0.08)',
        boxShadow: on ? `0 0 12px ${accent}88` : 'none',
        display:'flex', alignItems:'center', justifyContent: on ? 'flex-end' : 'flex-start',
      }}>
        <div style={{width:18, height:18, borderRadius:'50%', background:'#000'}}/>
      </div>
    </div>
  );
  return (
    <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden'}}>
      <Grid/>
      <div style={{position:'absolute', inset:0, padding:'72px 24px 28px', display:'flex', flexDirection:'column'}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:18}}>
          <div style={{color:PLIM.inkDim, fontSize:15}}>‹</div>
          <div style={{fontFamily:PLIM.mono, fontSize:10, color:PLIM.inkFaint, letterSpacing:1.5}}>05 / 06</div>
        </div>
        <div style={{fontSize:26, fontWeight:700, letterSpacing:-0.6, lineHeight:1.15}}>
          Escolha seus rails
        </div>
        <div style={{fontSize:13, color:PLIM.inkDim, marginTop:6, marginBottom:18, lineHeight:1.45}}>
          O pLim roteia automaticamente entre rails. Você pode ajustar depois.
        </div>
        {/* P:L:I:M is mandatory / highlighted */}
        <div style={{
          padding:'14px 16px', borderRadius:16, marginBottom:14,
          background:`linear-gradient(135deg, ${PLIM.neonSoft} 0%, ${PLIM.orangeSoft} 100%)`,
          border:`1px solid ${PLIM.neon}55`,
          boxShadow:`0 0 28px ${PLIM.neon}22`,
          display:'flex', alignItems:'center', gap:12,
        }}>
          <Logo size={36} glow={false}/>
          <div style={{flex:1}}>
            <div style={{fontSize:14, fontWeight:700, color:PLIM.ink, letterSpacing:-0.2}}>
              P:L:I:M micropayments
            </div>
            <div style={{fontSize:11, color:PLIM.inkDim, fontFamily:PLIM.mono, marginTop:1}}>
              AI2AI · frações de centavo · sempre on
            </div>
          </div>
          <Pill>NATIVO</Pill>
        </div>
        <div style={{
          fontFamily:PLIM.mono, fontSize:9, color:PLIM.inkFaint,
          letterSpacing:1.5, marginBottom:8, paddingLeft:4,
        }}>RAILS ADICIONAIS</div>
        <div style={{display:'flex', flexDirection:'column', gap:8, flex:1}}>
          <Rail sym="€" name="Fiat IBAN (SEPA)" sub="EUR · liquidação em 24h" on accent={PLIM.orange}/>
          <Rail sym="₿" name="Bitcoin" sub="BTC · Lightning + L1" on/>
          <Rail sym="Ξ" name="Ethereum" sub="ETH · USDT · EURC" on/>
          <Rail sym="◎" name="Solana" sub="SOL · USDC"/>
          <Rail sym="⇄" name="Auto-swap on-chain" sub="DEX agregado · pLim/agent" on accent={PLIM.orange}/>
        </div>
        <Btn variant="primary">Continuar</Btn>
        <StepDots step={4}/>
      </div>
    </div>
  );
}

// ═══════════════ SCREEN 7 — Mesh / node discovery ═══════════════
function S7_Mesh() {
  const Node = ({ name, kind, rssi, type, accent = PLIM.neon }) => (
    <div style={{
      display:'flex', alignItems:'center', gap:12, padding:'12px 14px',
      borderRadius:14, background:PLIM.surface, border:`1px solid ${PLIM.hairline}`,
    }}>
      <div style={{
        width:34, height:34, borderRadius:10,
        background:`${accent}14`, color:accent,
        display:'flex', alignItems:'center', justifyContent:'center',
        fontFamily:PLIM.mono, fontSize:11, fontWeight:700,
        border:`1px solid ${accent}33`,
      }}>{kind}</div>
      <div style={{flex:1, minWidth:0}}>
        <div style={{fontSize:13, fontWeight:600, color:PLIM.ink, fontFamily:PLIM.mono}}>{name}</div>
        <div style={{fontSize:10, color:PLIM.inkDim, fontFamily:PLIM.mono, letterSpacing:0.5}}>
          {type} · {rssi} dBm
        </div>
      </div>
      {/* signal bars */}
      <div style={{display:'flex', alignItems:'flex-end', gap:2, height:14}}>
        {[4,7,10,13].map((h,i)=>(
          <div key={i} style={{
            width:3, height:h, borderRadius:1,
            background: rssi > -70 ? accent : (i < 2 ? accent : 'rgba(255,255,255,0.15)'),
          }}/>
        ))}
      </div>
    </div>
  );
  return (
    <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden'}}>
      <Grid/>
      <div style={{position:'absolute', inset:0, padding:'72px 24px 28px', display:'flex', flexDirection:'column'}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:18}}>
          <div style={{color:PLIM.inkDim, fontSize:15}}>‹</div>
          <div style={{fontFamily:PLIM.mono, fontSize:10, color:PLIM.inkFaint, letterSpacing:1.5}}>06 / 06</div>
        </div>
        <div style={{fontSize:26, fontWeight:700, letterSpacing:-0.6, lineHeight:1.15}}>
          Nodes próximos
        </div>
        <div style={{fontSize:13, color:PLIM.inkDim, marginTop:6, marginBottom:14, lineHeight:1.45}}>
          Conecte-se a um validador para confirmar transações offline.
        </div>
        {/* radar viz */}
        <div style={{
          position:'relative', height:160, margin:'0 -8px 14px',
          borderRadius:18, background:PLIM.surface, border:`1px solid ${PLIM.hairline}`,
          overflow:'hidden',
        }}>
          {/* rings */}
          {[36,70,110].map((r,i)=>(
            <div key={i} style={{
              position:'absolute', top:'50%', left:'50%',
              width:r*2, height:r*2, marginLeft:-r, marginTop:-r,
              border:`1px solid ${PLIM.neon}${['44','22','11'][i]}`,
              borderRadius:'50%',
            }}/>
          ))}
          {/* sweep wedge */}
          <div style={{
            position:'absolute', top:'50%', left:'50%',
            width:240, height:240, marginLeft:-120, marginTop:-120, borderRadius:'50%',
            background:`conic-gradient(from 30deg, ${PLIM.neonGlow} 0deg, transparent 50deg)`,
            opacity:0.5,
          }}/>
          {/* center dot */}
          <div style={{
            position:'absolute', top:'50%', left:'50%', width:10, height:10, marginLeft:-5, marginTop:-5,
            borderRadius:'50%', background:PLIM.neon, boxShadow:`0 0 16px ${PLIM.neon}`,
          }}/>
          {/* discovered dots */}
          {[[80,52,PLIM.neon],[270,68,PLIM.orange],[110,128,PLIM.neon],[230,116,PLIM.neon]].map(([x,y,c],i)=>(
            <div key={i} style={{
              position:'absolute', left:x, top:y, width:8, height:8, borderRadius:'50%',
              background:c, boxShadow:`0 0 10px ${c}`,
            }}/>
          ))}
          <div style={{
            position:'absolute', top:10, left:12,
            fontFamily:PLIM.mono, fontSize:9, color:PLIM.neon, letterSpacing:1.5,
          }}>● SCANNING · 4 FOUND</div>
          <div style={{
            position:'absolute', top:10, right:12,
            fontFamily:PLIM.mono, fontSize:9, color:PLIM.inkFaint, letterSpacing:1.5,
          }}>RANGE 240m</div>
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:8, flex:1, overflow:'hidden'}}>
          <Node name="plim-node-a8f3" kind="BLE" rssi={-52} type="Blackbox · solar"/>
          <Node name="plim-node-c12e" kind="LoRa" rssi={-68} type="Validator · solar" accent={PLIM.orange}/>
          <Node name="plim-host-7d9a" kind="WiFi" rssi={-74} type="Desktop · macOS"/>
          <Node name="plim-node-b441" kind="LoRa" rssi={-88} type="Validator · offline"/>
        </div>
        <div style={{display:'flex', gap:8, marginTop:12}}>
          <div style={{flex:1}}><Btn variant="ghost">Pular</Btn></div>
          <div style={{flex:1.4}}><Btn variant="primary">Conectar</Btn></div>
        </div>
        <StepDots step={5}/>
      </div>
    </div>
  );
}

// ═══════════════ SCREEN 8 — Ready ═══════════════
function S8_Ready() {
  return (
    <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden'}}>
      <Grid/>
      <div style={{
        position:'absolute', top:'-10%', left:'-30%', right:'-30%', height:'80%',
        background:`radial-gradient(ellipse, ${PLIM.neonGlow} 0%, transparent 55%)`,
        filter:'blur(50px)', opacity:0.65,
      }}/>
      <div style={{
        position:'absolute', bottom:'-20%', left:'-20%', right:'-20%', height:'40%',
        background:`radial-gradient(ellipse, ${PLIM.orange}55 0%, transparent 60%)`,
        filter:'blur(60px)', opacity:0.4,
      }}/>
      <div style={{position:'absolute', inset:0, padding:'90px 28px 32px', display:'flex', flexDirection:'column'}}>
        <div style={{flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:22}}>
          {/* check ring */}
          <div style={{
            width:120, height:120, position:'relative',
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            <div style={{
              position:'absolute', inset:0, borderRadius:'50%',
              border:`2px solid ${PLIM.neon}`,
              boxShadow:`0 0 40px ${PLIM.neonGlow}, inset 0 0 24px ${PLIM.neonSoft}`,
            }}/>
            <div style={{
              position:'absolute', inset:14, borderRadius:'50%',
              border:`1px dashed ${PLIM.orange}66`,
            }}/>
            <Logo size={56} glow={false}/>
          </div>
          <div style={{textAlign:'center'}}>
            <div style={{fontSize:30, fontWeight:700, letterSpacing:-0.7}}>Wallet pronta</div>
            <div style={{fontSize:14, color:PLIM.inkDim, marginTop:8, lineHeight:1.45, maxWidth:300}}>
              Sua chave está no Secure Enclave. <span style={{color:PLIM.neon}}>3 nodes</span> próximos
              já te conhecem.
            </div>
          </div>
          {/* address */}
          <div style={{
            background:PLIM.surface, border:`1px solid ${PLIM.hairline}`,
            borderRadius:14, padding:'10px 14px',
            display:'flex', alignItems:'center', gap:10, maxWidth:'100%',
          }}>
            <div style={{
              width:8, height:8, borderRadius:'50%', background:PLIM.neon,
              boxShadow:`0 0 8px ${PLIM.neon}`,
            }}/>
            <div style={{fontFamily:PLIM.mono, fontSize:12, color:PLIM.ink, letterSpacing:-0.2}}>
              plim:1a8f…3c2e
            </div>
            <div style={{color:PLIM.inkDim, fontSize:14}}>⎘</div>
          </div>
          {/* status grid */}
          <div style={{
            display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, width:'100%', marginTop:8,
          }}>
            {[
              ['MESH','● ativo', PLIM.neon],
              ['INTERNET','● fallback', PLIM.orange],
              ['RAILS','5 ativos', PLIM.ink],
              ['SALDO','€0,00', PLIM.ink],
            ].map(([k,v,c],i)=>(
              <div key={i} style={{
                background:PLIM.surface, border:`1px solid ${PLIM.hairline}`,
                borderRadius:12, padding:'10px 12px',
              }}>
                <div style={{
                  fontFamily:PLIM.mono, fontSize:9, color:PLIM.inkFaint,
                  letterSpacing:1.5, marginBottom:4,
                }}>{k}</div>
                <div style={{fontSize:13, color:c, fontWeight:600, fontFamily:PLIM.mono}}>{v}</div>
              </div>
            ))}
          </div>
        </div>
        <Btn variant="primary">Abrir wallet</Btn>
      </div>
    </div>
  );
}

Object.assign(window, {
  S1_Welcome, S2_Path, S3_Privacy, S4_Passcode,
  S5_Seed, S6_Rails, S7_Mesh, S8_Ready,
  S0_Icon, AppIcon, Logo, Wordmark, Grid, Pill, Btn, StepDots,
  PLIM,
});

// ═══════════════ SCREEN 0 — App Icon preview (iOS home) ═══════════════
function S0_Icon() {
  // a faux home: pLim icon hero + grid of muted neighbour icons + dock
  const FauxIcon = ({ bg, glyph, color = '#fff', label }) => (
    <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:6}}>
      <div style={{
        width:60, height:60, borderRadius:14, background:bg,
        display:'flex', alignItems:'center', justifyContent:'center',
        color, fontSize:24, fontWeight:600,
        boxShadow:'0 4px 12px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.1)',
      }}>{glyph}</div>
      <div style={{fontSize:10, color:'rgba(255,255,255,0.85)', fontFamily:'-apple-system'}}>{label}</div>
    </div>
  );

  return (
    <div style={{
      position:'relative', height:'100%', overflow:'hidden',
      background:
        `radial-gradient(ellipse at 50% 15%, #1a2a3a 0%, #050708 55%),`+
        `linear-gradient(180deg, #06090a 0%, #02030a 100%)`,
      color:PLIM.ink,
    }}>
      {/* faint stars / circuit dots */}
      {Array.from({length: 30}).map((_, i) => {
        const x = (i * 53) % 100, y = (i * 31 + 7) % 100;
        const s = (i % 3) + 1;
        return <div key={i} style={{
          position:'absolute', left:`${x}%`, top:`${y}%`,
          width:s, height:s, borderRadius:'50%',
          background: i % 5 === 0 ? PLIM.cyan : 'rgba(255,255,255,0.4)',
          opacity: 0.3 + (i%4)*0.1,
        }}/>;
      })}

      <div style={{position:'absolute', inset:0, padding:'68px 24px 36px', display:'flex', flexDirection:'column'}}>
        {/* page indicator */}
        <div style={{
          fontFamily:PLIM.mono, fontSize:10, color:PLIM.inkFaint,
          letterSpacing:1.5, textAlign:'center', marginBottom:24,
        }}>● ● ●  ICON PREVIEW · iOS 17+  ● ● ●</div>

        {/* hero icon */}
        <div style={{display:'flex', justifyContent:'center', marginBottom:14}}>
          <AppIcon size={156}/>
        </div>
        <div style={{textAlign:'center', marginBottom:24}}>
          <div style={{fontSize:16, fontWeight:600, color:PLIM.ink}}>pLim Wallet</div>
          <div style={{
            fontFamily:PLIM.mono, fontSize:10, color:PLIM.inkDim,
            letterSpacing:2, marginTop:4, textTransform:'uppercase',
          }}>off-grid · resiliente</div>
        </div>

        {/* size variants strip */}
        <div style={{
          display:'flex', alignItems:'flex-end', justifyContent:'center', gap:14, marginBottom:22,
          padding:'14px 12px', borderRadius:16,
          background:'rgba(255,255,255,0.03)',
          border:`1px solid ${PLIM.hairline}`,
        }}>
          {[
            [76, '180'],
            [56, '120'],
            [40, '80'],
            [28, '58'],
          ].map(([s, label], i) => (
            <div key={i} style={{display:'flex', flexDirection:'column', alignItems:'center', gap:5}}>
              <AppIcon size={s} glow={false}/>
              <div style={{fontFamily:PLIM.mono, fontSize:9, color:PLIM.inkFaint, letterSpacing:0.5}}>{label}px</div>
            </div>
          ))}
        </div>

        <div style={{
          fontFamily:PLIM.mono, fontSize:9, color:PLIM.inkFaint,
          letterSpacing:1.5, textAlign:'center', marginBottom:10,
        }}>NA SUA TELA INICIAL</div>

        {/* neighbour grid */}
        <div style={{
          display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:18, marginBottom:18,
        }}>
          <FauxIcon bg="#1c1c1e" glyph="✉" label="Mail"/>
          <FauxIcon bg="linear-gradient(135deg,#5ac8fa,#007aff)" glyph="☀" label="Weather"/>
          <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:6}}>
            <AppIcon size={60} glow={false}/>
            <div style={{fontSize:10, color:PLIM.neon, fontWeight:600, fontFamily:'-apple-system'}}>pLim</div>
          </div>
          <FauxIcon bg="#000" glyph="₿" color="#f7931a" label="Wallet"/>
        </div>

        <div style={{flex:1}}/>

        {/* dock */}
        <div style={{
          margin:'0 -8px', padding:'10px 14px', borderRadius:26,
          background:'rgba(255,255,255,0.08)',
          backdropFilter:'blur(20px)', WebkitBackdropFilter:'blur(20px)',
          border:'1px solid rgba(255,255,255,0.08)',
          display:'flex', justifyContent:'space-around',
        }}>
          <FauxIcon bg="#34c759" glyph="☏" label=""/>
          <FauxIcon bg="linear-gradient(135deg,#5ac8fa,#0a84ff)" glyph="💬" label=""/>
          <div style={{display:'flex', flexDirection:'column', alignItems:'center'}}>
            <AppIcon size={60} glow/>
          </div>
          <FauxIcon bg="#0a84ff" glyph="⌖" label=""/>
        </div>
      </div>
    </div>
  );
}
