// wallet-core.jsx — Home, Send (3 steps), Receive — 2026 polished
const { PLIM, Logo, AppIcon, Wordmark, Grid, Pill, Btn, StepDots, Icon } = window;

// ───── Type helpers ─────
const T = {
  display: { fontSize:34, fontWeight:700, letterSpacing:-1, lineHeight:1.05, fontFamily:'-apple-system, system-ui' },
  title:   { fontSize:22, fontWeight:700, letterSpacing:-0.4, lineHeight:1.15, fontFamily:'-apple-system, system-ui' },
  heading: { fontSize:17, fontWeight:600, letterSpacing:-0.2, lineHeight:1.3, fontFamily:'-apple-system, system-ui' },
  body:    { fontSize:15, fontWeight:400, letterSpacing:-0.1, lineHeight:1.4, fontFamily:'-apple-system, system-ui' },
  bodySemi:{ fontSize:15, fontWeight:600, letterSpacing:-0.1, lineHeight:1.3, fontFamily:'-apple-system, system-ui' },
  caption: { fontSize:13, fontWeight:500, letterSpacing:-0.05, lineHeight:1.35, fontFamily:'-apple-system, system-ui' },
  micro:   { fontSize:11, fontWeight:600, letterSpacing:0.3, lineHeight:1.3, fontFamily:'-apple-system, system-ui' },
  // mono — ONLY for amounts, addresses, hashes
  amount:  { fontFamily:PLIM.mono, fontWeight:600, letterSpacing:-0.5 },
  code:    { fontFamily:PLIM.mono, fontWeight:500, letterSpacing:0 },
};
const eur = (v) => '€' + v.toLocaleString('pt-PT', {minimumFractionDigits:2, maximumFractionDigits:2}).replace(/,/g, ',').replace(/\u00A0/g, ' ');

// ───── Shared chrome ─────
const Shell = ({ children, title, sub, back, right, tab, dense = false }) => (
  <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden', display:'flex', flexDirection:'column'}}>
    {/* very subtle background — no grid, just a faint top glow on hero shells */}
    {!dense && <div style={{
      position:'absolute', top:-100, left:'50%', transform:'translateX(-50%)',
      width:400, height:200, borderRadius:'50%',
      background:`radial-gradient(ellipse, ${PLIM.cyanGlow} 0%, transparent 70%)`,
      opacity:0.18, filter:'blur(30px)', pointerEvents:'none',
    }}/>}
    {/* top bar */}
    <div style={{padding:'58px 20px 14px', display:'flex', alignItems:'center', gap:12, position:'relative', zIndex:2}}>
      {back && <div style={{
        width:36, height:36, borderRadius:18,
        background:'rgba(255,255,255,0.06)',
        display:'flex', alignItems:'center', justifyContent:'center',
        marginLeft:-6,
      }}><Icon name="chevron-left" size={20} color={PLIM.ink}/></div>}
      <div style={{flex:1, minWidth:0}}>
        {typeof title === 'string' ? (
          <>
            <div style={{...T.heading, color:PLIM.ink}}>{title}</div>
            {sub && <div style={{...T.micro, color:PLIM.inkFaint, textTransform:'uppercase', marginTop:3}}>{sub}</div>}
          </>
        ) : title}
      </div>
      {right}
    </div>
    <div style={{flex:1, overflow:'hidden', position:'relative', zIndex:1}}>{children}</div>
    {tab !== false && <TabBar active={tab}/>}
  </div>
);

const TabBar = ({ active = 'home' }) => {
  const items = [
    ['home','home','Início'],
    ['activity','list','Atividade'],
    ['send', null, ''],
    ['agents','sparkle','Agentes'],
    ['settings','user','Conta'],
  ];
  return (
    <div style={{
      padding:'10px 16px 28px',
      background:'rgba(6,9,10,0.92)', backdropFilter:'blur(24px) saturate(180%)', WebkitBackdropFilter:'blur(24px) saturate(180%)',
      borderTop:`1px solid ${PLIM.hairline}`, position:'relative', zIndex:5,
      display:'flex', alignItems:'center', gap:4,
    }}>
      {items.map(([id, icon, label]) => {
        const isCenter = id === 'send';
        const on = id === active;
        if (isCenter) {
          return (
            <div key={id} style={{flex:1, display:'flex', justifyContent:'center', marginTop:-26}}>
              <div style={{
                width:54, height:54, borderRadius:18,
                background:`linear-gradient(135deg, ${PLIM.neon} 0%, #6FFFB0 100%)`,
                color:'#001a08', display:'flex', alignItems:'center', justifyContent:'center',
                boxShadow:`0 0 28px ${PLIM.neonGlow}, 0 8px 20px rgba(0,0,0,0.5)`,
              }}>
                <Icon name="arrow-up" size={26} stroke={2.3} color="#001a08"/>
              </div>
            </div>
          );
        }
        return (
          <div key={id} style={{
            flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:3,
            color: on ? PLIM.neon : 'rgba(232,255,234,0.42)',
            padding:'4px 0',
          }}>
            <Icon name={icon} size={22} color="currentColor" stroke={on ? 2 : 1.75}/>
            <div style={{fontSize:10, fontWeight:600, letterSpacing:-0.05}}>{label}</div>
          </div>
        );
      })}
    </div>
  );
};

// shared atoms
const FlowBadge = ({ flow }) => {
  const map = {
    P2AI:[PLIM.neon, PLIM.neonSoft],
    B2AI:[PLIM.orange, PLIM.orangeSoft],
    G2AI:[PLIM.cyan, 'rgba(31,200,232,0.16)'],
    AI2AI:['#C792FF','rgba(199,146,255,0.14)']
  };
  const [c, bg] = map[flow] || map.P2AI;
  return (
    <span style={{
      display:'inline-flex', alignItems:'center',
      padding:'2px 7px', borderRadius:6,
      background:bg, color:c, fontSize:9, fontWeight:700,
      letterSpacing:0.4, fontFamily:'-apple-system',
      border:`1px solid ${c}26`,
    }}>{flow}</span>
  );
};
const Dot = ({ c }) => <span style={{display:'inline-block', width:6, height:6, borderRadius:'50%', background:c, boxShadow:`0 0 6px ${c}66`}}/>;
const Mono = ({ children, size = 12, color = PLIM.inkDim }) => (
  <span style={{...T.code, fontSize:size, color}}>{children}</span>
);

// ═══════════════ HOME ═══════════════
function W_Home() {
  const tokens = [
    { sym:'ePL',  name:'ePL',         bal:'12 448,09', fiat:2489.62, d:'+2,4%',  up:true,  c:PLIM.neon },
    { sym:'EURC', name:'Euro Coin',   bal:'1 204,50',  fiat:1204.50, d:'0,0%',   up:true,  c:'#1a4dff' },
    { sym:'USDC', name:'USD Coin',    bal:'342,18',    fiat:317.40,  d:'+0,1%',  up:true,  c:'#2775ca' },
    { sym:'BRZ',  name:'Brazil R$',   bal:'4 820,00',  fiat:805.30,  d:'-0,8%',  up:false, c:'#00a868' },
  ];
  return (
    <Shell tab="home" title={
      <div style={{display:'flex', alignItems:'center', gap:10}}>
        <Logo size={28} glow={false}/>
        <div style={{...T.heading, color:PLIM.ink}}>pLim</div>
      </div>
    } right={
      <div style={{display:'flex', gap:8, alignItems:'center'}}>
        <div style={{
          width:36, height:36, borderRadius:18, background:'rgba(255,255,255,0.06)',
          display:'flex', alignItems:'center', justifyContent:'center',
        }}><Icon name="bell" size={18} color={PLIM.ink}/></div>
        <div style={{
          width:36, height:36, borderRadius:18,
          background:`linear-gradient(135deg, ${PLIM.cyan}, ${PLIM.neon})`,
          display:'flex', alignItems:'center', justifyContent:'center',
          color:'#000', fontWeight:700, fontSize:13,
        }}>PD</div>
      </div>
    }>
      <div style={{overflow:'auto', height:'100%', padding:'0 16px 12px'}}>
        {/* balance hero */}
        <div style={{padding:'8px 4px 22px'}}>
          <div style={{...T.micro, color:PLIM.inkFaint, textTransform:'uppercase', marginBottom:8}}>Saldo total</div>
          <div style={{display:'flex', alignItems:'baseline', gap:4}}>
            <span style={{...T.amount, fontSize:44, color:PLIM.ink, letterSpacing:-1.5}}>€4 816</span>
            <span style={{...T.amount, fontSize:24, color:PLIM.inkDim, letterSpacing:-0.8}}>,82</span>
          </div>
          <div style={{display:'flex', alignItems:'center', gap:8, marginTop:8}}>
            <Icon name="arrow-up" size={14} color={PLIM.neon}/>
            <span style={{...T.caption, color:PLIM.neon}}>€112,40</span>
            <span style={{...T.caption, color:PLIM.inkDim}}>+2,4% hoje</span>
          </div>
        </div>

        {/* primary actions */}
        <div style={{display:'flex', gap:8, marginBottom:18}}>
          {[
            ['send','Enviar', PLIM.neon, true],
            ['receive','Receber', null, false],
            ['swap','Swap', null, false],
            ['scan','Ler', null, false],
          ].map(([icon, label, hl, primary], i) => (
            <div key={icon} style={{
              flex:1, padding:'14px 0', borderRadius:14,
              background: primary ? `linear-gradient(180deg, ${PLIM.neon}24 0%, ${PLIM.neon}10 100%)` : 'rgba(255,255,255,0.04)',
              border:`1px solid ${primary ? PLIM.neon+'55' : PLIM.hairline}`,
              display:'flex', flexDirection:'column', alignItems:'center', gap:6,
              boxShadow: primary ? `0 0 16px ${PLIM.neon}11` : 'none',
            }}>
              <Icon name={icon} size={20} color={primary ? PLIM.neon : PLIM.ink} stroke={1.85}/>
              <div style={{...T.caption, color: primary ? PLIM.neon : PLIM.ink, fontSize:12}}>{label}</div>
            </div>
          ))}
        </div>

        {/* agent attention */}
        <div style={{
          padding:'14px', borderRadius:16, marginBottom:18,
          background:`linear-gradient(135deg, ${PLIM.orangeSoft} 0%, rgba(14,19,17,0.5) 100%)`,
          border:`1px solid ${PLIM.orange}44`,
          display:'flex', alignItems:'center', gap:12,
        }}>
          <div style={{
            width:40, height:40, borderRadius:12, flexShrink:0,
            background:`${PLIM.orange}22`, border:`1px solid ${PLIM.orange}55`,
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            <Icon name="sparkle" size={20} color={PLIM.orange} fill={PLIM.orange+'33'} stroke={2}/>
          </div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{...T.bodySemi, color:PLIM.ink, fontSize:14}}>NovaShop precisa de você</div>
            <div style={{...T.caption, color:PLIM.inkDim, marginTop:1}}>2 pagamentos · {eur(87.30)} aguardando</div>
          </div>
          <div style={{
            padding:'6px 12px', borderRadius:999,
            background:PLIM.orange, color:'#1a0a00',
            ...T.caption, fontSize:12, fontWeight:700,
          }}>Revisar</div>
        </div>

        {/* tokens header */}
        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', margin:'0 4px 10px'}}>
          <div style={{...T.heading, color:PLIM.ink, fontSize:15}}>Ativos</div>
          <div style={{...T.caption, color:PLIM.neon, fontSize:12, display:'flex', alignItems:'center', gap:4}}>
            <Icon name="plus" size={14} color={PLIM.neon}/>
            Adicionar
          </div>
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:6}}>
          {tokens.map(t => (
            <div key={t.sym} style={{
              background:'rgba(255,255,255,0.03)',
              borderRadius:14, padding:'12px 14px',
              display:'flex', alignItems:'center', gap:12,
            }}>
              <div style={{
                width:38, height:38, borderRadius:'50%',
                background: t.sym==='ePL'
                  ? `linear-gradient(135deg, ${PLIM.cyan}, ${PLIM.neon})`
                  : t.c,
                display:'flex', alignItems:'center', justifyContent:'center',
                color:'#000', fontWeight:700, fontSize:11,
                flexShrink:0, fontFamily:PLIM.mono, letterSpacing:-0.3,
              }}>{t.sym}</div>
              <div style={{flex:1, minWidth:0}}>
                <div style={{...T.bodySemi, color:PLIM.ink, fontSize:14}}>{t.name}</div>
                <div style={{...T.caption, color:PLIM.inkDim, marginTop:1}}>
                  <span style={{...T.code, fontSize:12}}>{t.bal}</span> <span style={{fontSize:11}}>{t.sym}</span>
                </div>
              </div>
              <div style={{textAlign:'right', flexShrink:0}}>
                <div style={{...T.amount, color:PLIM.ink, fontSize:14}}>{eur(t.fiat)}</div>
                <div style={{...T.caption, color: t.up ? PLIM.neon : PLIM.red, fontSize:11, marginTop:1}}>{t.d}</div>
              </div>
            </div>
          ))}
        </div>

        {/* activity */}
        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', margin:'24px 4px 10px'}}>
          <div style={{...T.heading, color:PLIM.ink, fontSize:15}}>Recente</div>
          <div style={{...T.caption, color:PLIM.inkDim, fontSize:12, display:'flex', alignItems:'center', gap:4}}>
            Ver tudo
            <Icon name="chevron-right" size={14} color={PLIM.inkDim}/>
          </div>
        </div>
        <div style={{display:'flex', flexDirection:'column'}}>
          {[
            { dir:'in',  who:'Maria López',   amt:120.00,  tok:'EURC', flow:'P2AI', t:'12 min',  agent:false},
            { dir:'out', who:'NovaShop',      amt:-34.80,  tok:'EURC', flow:'B2AI', t:'2 h',     agent:true,  pending:true},
            { dir:'out', who:'agent · BookKeep', amt:-0.012, tok:'ePL', flow:'AI2AI', t:'4 h',   agent:true},
            { dir:'in',  who:'João Pessoa Gov', amt:580.00, tok:'BRZ', flow:'G2AI', t:'ontem',   agent:false},
          ].map((r, i) => (
            <div key={i} style={{
              padding:'12px 4px', display:'flex', alignItems:'center', gap:12,
              borderBottom: i < 3 ? `1px solid ${PLIM.hairline}` : 'none',
            }}>
              <div style={{
                width:36, height:36, borderRadius:'50%',
                background: r.dir==='in' ? `${PLIM.neon}18` : 'rgba(255,255,255,0.05)',
                display:'flex', alignItems:'center', justifyContent:'center',
                flexShrink:0, position:'relative',
              }}>
                <Icon name={r.dir==='in' ? 'arrow-down' : 'arrow-up'} size={16}
                      color={r.dir==='in' ? PLIM.neon : PLIM.ink} stroke={2}/>
                {r.agent && <div style={{
                  position:'absolute', bottom:-2, right:-2, width:16, height:16, borderRadius:'50%',
                  background:PLIM.orange,
                  border:`2px solid #06090A`,
                  display:'flex', alignItems:'center', justifyContent:'center',
                }}>
                  <Icon name="sparkle" size={9} color="#000" fill="#000" stroke={0}/>
                </div>}
              </div>
              <div style={{flex:1, minWidth:0}}>
                <div style={{...T.bodySemi, color:PLIM.ink, fontSize:14, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>{r.who}</div>
                <div style={{display:'flex', gap:8, alignItems:'center', marginTop:2}}>
                  <FlowBadge flow={r.flow}/>
                  <span style={{...T.caption, color:PLIM.inkDim, fontSize:11}}>há {r.t}</span>
                  {r.pending && <span style={{...T.caption, color:PLIM.orange, fontSize:11, display:'flex', alignItems:'center', gap:3}}><Dot c={PLIM.orange}/>pendente</span>}
                </div>
              </div>
              <div style={{textAlign:'right', flexShrink:0}}>
                <div style={{...T.amount, fontSize:14, color: r.dir==='in' ? PLIM.neon : PLIM.ink}}>
                  {r.dir==='in' ? '+' : '−'}{r.tok === 'ePL' ? Math.abs(r.amt).toFixed(3) : eur(Math.abs(r.amt))}
                </div>
                <div style={{...T.caption, color:PLIM.inkFaint, fontSize:10, marginTop:1, fontFamily:PLIM.mono}}>{r.tok}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Shell>
  );
}

// ═══════════════ SEND · Step 1 — Compose ═══════════════
function W_Send1() {
  return (
    <Shell tab="send" back title="Para quem?" sub="Etapa 1 de 3">
      <div style={{padding:'0 20px 16px', overflow:'auto', height:'100%', display:'flex', flexDirection:'column'}}>
        {/* recipient selected */}
        <div style={{
          padding:'14px', borderRadius:16,
          background:`linear-gradient(135deg, ${PLIM.neonSoft} 0%, rgba(14,19,17,0.4) 100%)`,
          border:`1px solid ${PLIM.neon}44`,
          display:'flex', alignItems:'center', gap:12, marginBottom:8,
        }}>
          <div style={{
            width:42, height:42, borderRadius:'50%',
            background:`linear-gradient(135deg, #FFB870, ${PLIM.orange})`,
            display:'flex', alignItems:'center', justifyContent:'center',
            color:'#1a0a00', fontWeight:700, fontSize:14,
          }}>ML</div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{display:'flex', alignItems:'center', gap:6}}>
              <div style={{...T.bodySemi, color:PLIM.ink, fontSize:15}}>Maria López</div>
              <span style={{fontSize:11, color:PLIM.inkDim}}>· ES</span>
            </div>
            <div style={{...T.caption, color:PLIM.inkDim, marginTop:1, display:'flex', alignItems:'center', gap:5}}>
              <Icon name="shield-check" size={12} color={PLIM.neon}/>
              <span style={{...T.code, fontSize:11}}>plim:1a8f…3c2e</span>
            </div>
          </div>
          <div style={{
            width:36, height:36, borderRadius:18, background:'rgba(255,255,255,0.06)',
            display:'flex', alignItems:'center', justifyContent:'center',
          }}><Icon name="close" size={16} color={PLIM.inkDim}/></div>
        </div>
        <div style={{display:'flex', gap:8, marginBottom:24}}>
          {[['copy','Colar'],['scan','Ler QR'],['users','Contatos']].map(([icon, label])=>(
            <div key={label} style={{
              flex:1, height:38, borderRadius:10,
              background:'rgba(255,255,255,0.04)', border:`1px solid ${PLIM.hairline}`,
              display:'flex', alignItems:'center', justifyContent:'center', gap:6,
              ...T.caption, color:PLIM.inkDim, fontSize:12,
            }}>
              <Icon name={icon} size={14} color={PLIM.inkDim}/>
              {label}
            </div>
          ))}
        </div>

        {/* amount */}
        <div style={{textAlign:'center', padding:'20px 0 12px'}}>
          <div style={{display:'flex', alignItems:'baseline', justifyContent:'center', gap:4}}>
            <span style={{...T.amount, fontSize:24, color:PLIM.inkDim}}>€</span>
            <span style={{...T.amount, fontSize:64, color:PLIM.ink, letterSpacing:-2}}>120</span>
            <span style={{...T.amount, fontSize:32, color:PLIM.inkDim, letterSpacing:-1}}>,00</span>
          </div>
          <div style={{...T.caption, color:PLIM.inkDim, marginTop:6, display:'flex', alignItems:'center', justifyContent:'center', gap:6}}>
            <span style={{...T.code, fontSize:12}}>120,00 EURC</span>
            <span>·</span>
            <Icon name="clock" size={12} color={PLIM.inkFaint}/>
            <span style={{fontSize:11}}>cotação 12 s</span>
          </div>
        </div>

        {/* cap gauge */}
        <div style={{
          padding:'12px 14px', borderRadius:14, marginTop:16,
          background:'rgba(255,255,255,0.03)', border:`1px solid ${PLIM.hairline}`,
        }}>
          <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
            <div style={{display:'flex', alignItems:'center', gap:8}}>
              <Icon name="shield" size={14} color={PLIM.inkDim}/>
              <span style={{...T.caption, color:PLIM.inkDim, fontSize:12}}>Limite diário · KYC básico</span>
            </div>
            <span style={{...T.caption, color:PLIM.neon, fontSize:12, ...T.code}}>€340 / €1.000</span>
          </div>
          <div style={{height:4, borderRadius:2, background:'rgba(255,255,255,0.08)', marginTop:8, overflow:'hidden'}}>
            <div style={{width:'34%', height:'100%', background:PLIM.neon, boxShadow:`0 0 6px ${PLIM.neon}`, borderRadius:2}}/>
          </div>
        </div>

        {/* token + memo */}
        <div style={{marginTop:16, display:'flex', flexDirection:'column', gap:8}}>
          <div style={{
            padding:'14px', borderRadius:14,
            background:'rgba(255,255,255,0.03)', border:`1px solid ${PLIM.hairline}`,
            display:'flex', alignItems:'center', gap:12,
          }}>
            <div style={{
              width:32, height:32, borderRadius:'50%', background:'#1a4dff',
              display:'flex', alignItems:'center', justifyContent:'center',
              color:'#fff', fontWeight:700, fontSize:10,
            }}>EURC</div>
            <div style={{flex:1}}>
              <div style={{...T.bodySemi, color:PLIM.ink, fontSize:14}}>Euro Coin</div>
              <div style={{...T.caption, color:PLIM.inkDim, fontSize:11, ...T.code}}>saldo {eur(1204.50)}</div>
            </div>
            <Icon name="chevron-down" size={16} color={PLIM.inkDim}/>
          </div>
          <div style={{
            padding:'14px', borderRadius:14,
            background:'rgba(255,255,255,0.03)', border:`1px solid ${PLIM.hairline}`,
            display:'flex', alignItems:'center', gap:12,
          }}>
            <div style={{flex:1}}>
              <div style={{...T.caption, color:PLIM.inkDim, fontSize:11, marginBottom:2}}>Memo</div>
              <div style={{...T.code, color:PLIM.ink, fontSize:13}}>INV-2026-0044</div>
            </div>
            <Icon name="info" size={14} color={PLIM.orange}/>
          </div>
        </div>

        <div style={{flex:1, minHeight:20}}/>
        <Btn variant="primary">
          <span style={{display:'flex', alignItems:'center', gap:8}}>
            Continuar
            <Icon name="chevron-right" size={16} color="currentColor" stroke={2.2}/>
          </span>
        </Btn>
      </div>
    </Shell>
  );
}

// ═══════════════ SEND · Step 2 — Route & Review ═══════════════
function W_Send2() {
  return (
    <Shell tab="send" back title="Como enviar?" sub="Etapa 2 de 3">
      <div style={{padding:'0 20px 16px', overflow:'auto', height:'100%', display:'flex', flexDirection:'column'}}>
        {/* selected route */}
        <div style={{
          padding:'18px', borderRadius:18,
          background:`linear-gradient(135deg, ${PLIM.neonSoft} 0%, rgba(14,19,17,0.5) 100%)`,
          border:`1px solid ${PLIM.neon}66`,
          boxShadow:`0 0 28px ${PLIM.neon}11`,
        }}>
          <div style={{display:'flex', alignItems:'center', gap:8, marginBottom:12}}>
            <div style={{
              width:24, height:24, borderRadius:6,
              background:PLIM.neon, color:'#001a08',
              display:'flex', alignItems:'center', justifyContent:'center',
            }}>
              <Icon name="check" size={14} stroke={2.5}/>
            </div>
            <span style={{...T.micro, color:PLIM.neon, textTransform:'uppercase'}}>Melhor rota</span>
          </div>
          <div style={{...T.title, color:PLIM.ink, fontSize:24}}>SEPA Instant</div>
          <div style={{...T.caption, color:PLIM.inkDim, marginTop:4}}>via Bank Partner X · jurisdição ES</div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginTop:16}}>
            {[
              ['custo', '€0,02', 'coin'],
              ['chegada', '~8 s', 'clock'],
              ['rede', 'HTTPS', 'globe'],
            ].map(([k,v,icon])=>(
              <div key={k} style={{
                padding:'10px 12px', borderRadius:10,
                background:'rgba(0,0,0,0.25)',
              }}>
                <div style={{display:'flex', alignItems:'center', gap:5, marginBottom:4}}>
                  <Icon name={icon} size={11} color={PLIM.inkFaint}/>
                  <span style={{...T.micro, color:PLIM.inkFaint, textTransform:'uppercase', fontSize:9}}>{k}</span>
                </div>
                <div style={{...T.bodySemi, color:PLIM.ink, fontSize:14, ...T.code}}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* rationale */}
        <div style={{marginTop:18}}>
          <div style={{...T.micro, color:PLIM.inkFaint, textTransform:'uppercase', marginBottom:10}}>Por que esta rota</div>
          <div style={{display:'flex', flexDirection:'column', gap:8}}>
            {[
              'Menor custo entre as opções fiat',
              'Destinatário na mesma jurisdição MiCA',
              'Sem necessidade de quórum abaixo de €1.000',
            ].map((r, i) => (
              <div key={i} style={{display:'flex', gap:10, alignItems:'flex-start'}}>
                <Icon name="check" size={14} color={PLIM.neon} stroke={2.5} style={{marginTop:3}}/>
                <div style={{...T.body, color:PLIM.ink, fontSize:14}}>{r}</div>
              </div>
            ))}
          </div>
        </div>

        {/* alternatives toggle */}
        <div style={{
          marginTop:16, padding:'14px', borderRadius:14,
          background:'rgba(255,255,255,0.03)', border:`1px solid ${PLIM.hairline}`,
          display:'flex', alignItems:'center', gap:12,
        }}>
          <Icon name="route" size={18} color={PLIM.inkDim}/>
          <div style={{flex:1}}>
            <div style={{...T.bodySemi, color:PLIM.ink, fontSize:14}}>3 rotas alternativas</div>
            <div style={{...T.caption, color:PLIM.inkDim, fontSize:11}}>P:L:I:M nativo · USDC Solana · L99 mesh</div>
          </div>
          <Icon name="chevron-right" size={16} color={PLIM.inkDim}/>
        </div>

        <div style={{flex:1, minHeight:14}}/>
        <Btn variant="primary">
          <span style={{display:'flex', alignItems:'center', gap:8}}>
            Continuar
            <Icon name="chevron-right" size={16} color="currentColor" stroke={2.2}/>
          </span>
        </Btn>
      </div>
    </Shell>
  );
}

// ═══════════════ SEND · Step 3 — Sign ═══════════════
function W_Send3() {
  return (
    <div style={{position:'relative', height:'100%', background:PLIM.bg, color:PLIM.ink, overflow:'hidden'}}>
      <div style={{
        position:'absolute', inset:0, background:'rgba(0,0,0,0.55)',
        backdropFilter:'blur(12px)', WebkitBackdropFilter:'blur(12px)',
      }}/>
      <div style={{
        position:'absolute', left:12, right:12, top:60, bottom:24,
        background:`linear-gradient(180deg, #0b1311 0%, #060908 100%)`,
        borderRadius:28, border:`1px solid ${PLIM.neon}44`,
        boxShadow:`0 0 0 1px ${PLIM.neon}22, 0 0 40px ${PLIM.neon}33, 0 30px 60px rgba(0,0,0,0.6)`,
        padding:'24px 22px', display:'flex', flexDirection:'column', gap:16,
        overflow:'auto',
      }}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div style={{display:'flex', alignItems:'center', gap:8}}>
            <Icon name="shield-check" size={16} color={PLIM.neon}/>
            <span style={{...T.micro, color:PLIM.neon, textTransform:'uppercase'}}>Confirmar pagamento</span>
          </div>
          <span style={{...T.micro, color:PLIM.inkFaint}}>3 / 3</span>
        </div>

        {/* sentence summary */}
        <div style={{...T.title, color:PLIM.ink, fontSize:22, lineHeight:1.35}}>
          Enviar <span style={{color:PLIM.neon, ...T.code}}>{eur(120)}</span> em <span style={{...T.code}}>EURC</span> para <span style={{color:PLIM.orange}}>Maria López</span>
        </div>

        {/* recipient row */}
        <div style={{
          padding:'12px', borderRadius:12, background:'rgba(255,255,255,0.04)',
          display:'flex', alignItems:'center', gap:12,
        }}>
          <div style={{
            width:36, height:36, borderRadius:'50%',
            background:`linear-gradient(135deg, #FFB870, ${PLIM.orange})`,
            display:'flex', alignItems:'center', justifyContent:'center',
            color:'#1a0a00', fontWeight:700, fontSize:13,
          }}>ML</div>
          <div style={{flex:1}}>
            <div style={{...T.bodySemi, color:PLIM.ink, fontSize:14}}>Maria López</div>
            <Mono size={11}>plim:1a8f…3c2e</Mono>
          </div>
          <FlowBadge flow="B2AI"/>
        </div>

        {/* agent attestation */}
        <div style={{
          padding:'14px', borderRadius:14,
          background:`linear-gradient(135deg, ${PLIM.orangeSoft} 0%, transparent 100%)`,
          border:`1px solid ${PLIM.orange}55`,
        }}>
          <div style={{display:'flex', alignItems:'center', gap:10, marginBottom:10}}>
            <div style={{
              width:32, height:32, borderRadius:10,
              background:`${PLIM.orange}22`, border:`1px solid ${PLIM.orange}55`,
              display:'flex', alignItems:'center', justifyContent:'center',
            }}>
              <Icon name="sparkle" size={16} color={PLIM.orange} fill={PLIM.orange+'33'} stroke={2}/>
            </div>
            <div style={{flex:1, minWidth:0}}>
              <div style={{display:'flex', alignItems:'center', gap:6}}>
                <span style={{...T.bodySemi, color:PLIM.ink, fontSize:14}}>NovaShop</span>
                <span style={{...T.caption, color:PLIM.inkDim, fontSize:11}}>· agente B2AI</span>
              </div>
              <div style={{...T.caption, color:PLIM.inkDim, fontSize:11}}>co-assinando neste mandato</div>
            </div>
            <div style={{
              padding:'4px 8px', borderRadius:6,
              background:PLIM.neonSoft, color:PLIM.neon,
              ...T.micro, fontSize:9, display:'flex', alignItems:'center', gap:4,
            }}>
              <Icon name="shield-check" size={10} color={PLIM.neon}/>
              Verificado
            </div>
          </div>
          {/* mandate gauge */}
          <div>
            <div style={{display:'flex', justifyContent:'space-between', marginBottom:6}}>
              <span style={{...T.caption, color:PLIM.inkDim, fontSize:11}}>Mandato usado hoje</span>
              <span style={{...T.code, color:PLIM.orange, fontSize:11}}>{eur(155.20)} / €500</span>
            </div>
            <div style={{height:3, borderRadius:2, background:'rgba(255,255,255,0.08)'}}>
              <div style={{width:'31%', height:'100%', background:PLIM.orange, borderRadius:2, boxShadow:`0 0 4px ${PLIM.orange}`}}/>
            </div>
          </div>
        </div>

        {/* small risk bullet */}
        <div style={{
          padding:'10px 12px', borderRadius:12,
          background:`${PLIM.cyan}10`, border:`1px solid ${PLIM.cyan}33`,
          display:'flex', gap:10, alignItems:'flex-start',
        }}>
          <Icon name="info" size={14} color={PLIM.cyan} style={{marginTop:2}}/>
          <div style={{...T.caption, color:PLIM.ink, fontSize:12, lineHeight:1.45}}>
            Primeiro pagamento via SEPA · contraparte com 12 transações anteriores
          </div>
        </div>

        <div style={{flex:1}}/>

        {/* sign CTA */}
        <div style={{
          padding:'14px 16px', borderRadius:16,
          background:`linear-gradient(135deg, ${PLIM.neon} 0%, #6FFFB0 100%)`,
          boxShadow:`0 0 32px ${PLIM.neonGlow}`,
          display:'flex', alignItems:'center', gap:14, color:'#001a08',
        }}>
          <div style={{
            width:44, height:44, borderRadius:'50%',
            background:'rgba(0,0,0,0.12)', display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            <Icon name="face-id" size={22} color="#001a08" stroke={2.2}/>
          </div>
          <div style={{flex:1}}>
            <div style={{...T.bodySemi, fontSize:15, color:'#001a08'}}>Confirmar com Face ID</div>
            <div style={{...T.caption, fontSize:11, color:'#001a08', opacity:0.7}}>olhe para o dispositivo</div>
          </div>
          <Icon name="chevron-right" size={20} color="#001a08" stroke={2.2}/>
        </div>
        <div style={{display:'flex', gap:8}}>
          <div style={{flex:1, height:44, borderRadius:12, background:'rgba(255,255,255,0.04)', border:`1px solid ${PLIM.hairline}`, display:'flex', alignItems:'center', justifyContent:'center', ...T.caption, color:PLIM.ink, fontSize:13}}>Cancelar</div>
          <div style={{flex:1.4, height:44, borderRadius:12, background:'rgba(255,255,255,0.04)', border:`1px solid ${PLIM.hairline}`, display:'flex', alignItems:'center', justifyContent:'center', ...T.caption, color:PLIM.inkDim, fontSize:13, gap:6}}>
            <Icon name="users" size={14} color={PLIM.inkDim}/>
            Pedir quórum
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════ RECEIVE ═══════════════
function W_Receive() {
  return (
    <Shell back title="Receber">
      <div style={{padding:'0 20px 16px', overflow:'auto', height:'100%'}}>
        {/* tab toggle */}
        <div style={{
          padding:3, borderRadius:12, background:'rgba(255,255,255,0.05)',
          display:'flex', marginBottom:20,
        }}>
          {['QR instantâneo','Solicitar valor'].map((t, i) => (
            <div key={t} style={{
              flex:1, padding:'9px 10px', borderRadius:10, textAlign:'center',
              background: i===0 ? PLIM.ink : 'transparent',
              color: i===0 ? '#000' : PLIM.inkDim,
              ...T.caption, fontSize:13, fontWeight:600,
            }}>{t}</div>
          ))}
        </div>

        {/* QR card */}
        <div style={{
          padding:24, borderRadius:24,
          background:'#fff',
          textAlign:'center',
          boxShadow:`0 0 40px ${PLIM.cyan}33, 0 20px 40px rgba(0,0,0,0.4)`,
          position:'relative',
        }}>
          {/* fake QR */}
          <div style={{position:'relative', width:200, height:200, margin:'0 auto'}}>
            <svg viewBox="0 0 25 25" width="100%" height="100%" shapeRendering="crispEdges">
              {Array.from({length:25*25}).map((_,i)=>{
                const x = i%25, y = Math.floor(i/25);
                const corner = (x<7 && y<7) || (x>=18 && y<7) || (x<7 && y>=18);
                const inner = (x>=2 && x<=4 && y>=2 && y<=4) || (x>=20 && x<=22 && y>=2 && y<=4) || (x>=2 && x<=4 && y>=20 && y<=22);
                const frame = corner && !((x>=1 && x<=5 && y>=1 && y<=5) || (x>=19 && x<=23 && y>=1 && y<=5) || (x>=1 && x<=5 && y>=19 && y<=23));
                const rand = ((x*31 + y*17 + 7) % 11) < 5;
                const fill = inner || frame || (rand && !corner);
                const isCenter = x >= 10 && x <= 14 && y >= 10 && y <= 14;
                return fill && !isCenter ? <rect key={i} x={x} y={y} width="1" height="1" fill="#000"/> : null;
              })}
            </svg>
            <div style={{
              position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)',
              width:42, height:42, borderRadius:10, background:'#06090A',
              display:'flex', alignItems:'center', justifyContent:'center',
              padding:6,
            }}>
              <Logo size={26} glow={false}/>
            </div>
          </div>
          <div style={{marginTop:18}}>
            <div style={{...T.bodySemi, color:'#000', fontSize:16}}>Pedro Debize</div>
            <div style={{...T.code, fontSize:11, color:'#666', marginTop:2}}>plim:1a8f3c2e…b441d9</div>
          </div>
        </div>

        {/* copy */}
        <div style={{
          marginTop:14, padding:'12px 14px', borderRadius:12,
          background:'rgba(255,255,255,0.04)', border:`1px solid ${PLIM.hairline}`,
          display:'flex', alignItems:'center', gap:10,
        }}>
          <Icon name="qr" size={18} color={PLIM.inkDim}/>
          <div style={{flex:1, ...T.code, fontSize:12, color:PLIM.ink}}>plim:1a8f3c2e…b441d9</div>
          <Icon name="copy" size={16} color={PLIM.neon}/>
        </div>

        {/* tokens accepted */}
        <div style={{marginTop:20, ...T.micro, color:PLIM.inkFaint, textTransform:'uppercase', marginBottom:8}}>Aceito</div>
        <div style={{display:'flex', gap:6, flexWrap:'wrap'}}>
          {['ePL','EURC','USDC','BRZ','SOL','BTC'].map(s=>(
            <div key={s} style={{
              padding:'7px 12px', borderRadius:999,
              background:'rgba(255,255,255,0.04)', border:`1px solid ${PLIM.hairline}`,
              ...T.code, fontSize:11, color:PLIM.ink,
            }}>{s}</div>
          ))}
        </div>

        {/* mesh toggle */}
        <div style={{
          marginTop:18, padding:'14px', borderRadius:14,
          background:'rgba(255,255,255,0.03)', border:`1px solid ${PLIM.hairline}`,
          display:'flex', alignItems:'center', gap:12,
        }}>
          <div style={{
            width:36, height:36, borderRadius:10, background:`${PLIM.orange}18`,
            border:`1px solid ${PLIM.orange}44`,
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            <Icon name="broadcast" size={18} color={PLIM.orange}/>
          </div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{...T.bodySemi, color:PLIM.ink, fontSize:14}}>Modo mesh</div>
            <div style={{...T.caption, color:PLIM.inkDim, fontSize:11}}>QR compacto · funciona offline</div>
          </div>
          <div style={{
            width:42, height:24, borderRadius:12, padding:2, background:'rgba(255,255,255,0.08)',
            display:'flex', alignItems:'center', justifyContent:'flex-start',
          }}>
            <div style={{width:20, height:20, borderRadius:'50%', background:'#fff'}}/>
          </div>
        </div>

        {/* share */}
        <div style={{display:'flex', gap:8, marginTop:16}}>
          <div style={{
            flex:1, height:48, borderRadius:14,
            background:'rgba(255,255,255,0.04)', border:`1px solid ${PLIM.hairline}`,
            display:'flex', alignItems:'center', justifyContent:'center', gap:8,
            color:PLIM.ink, ...T.bodySemi, fontSize:14,
          }}>
            <Icon name="copy" size={16} color={PLIM.ink}/>
            Copiar
          </div>
          <div style={{
            flex:1, height:48, borderRadius:14,
            background:PLIM.neon, color:'#001a08',
            display:'flex', alignItems:'center', justifyContent:'center', gap:8,
            ...T.bodySemi, fontSize:14,
            boxShadow:`0 0 20px ${PLIM.neonGlow}`,
          }}>
            <Icon name="share" size={16} color="#001a08" stroke={2.2}/>
            Compartilhar
          </div>
        </div>
      </div>
    </Shell>
  );
}

Object.assign(window, { W_Home, W_Send1, W_Send2, W_Send3, W_Receive, Shell, TabBar, Mono, FlowBadge, Dot, T, eur });
